ETHICAL ASSISTANT - C++ SOURCE BUNDLE

This package contains:
- C++ source for the demo recorder UI (including consent_window_demo.cpp)
- .NET RecorderBridge API source
- React UI source

Quick start on client machine:
1) Install dependencies:
   - CMake + GCC/G++
   - GTK3 dev + GStreamer dev + curl dev
   - .NET SDK (net10.0)
   - Node.js + npm

2) Build C++ demo:
   ./scripts/build_cpp_demo.sh

3) Start backend API:
   ./scripts/run_backend.sh

4) Start frontend UI in another terminal:
   ./scripts/run_frontend.sh

5) Open browser:
   http://localhost:5173

One-command run (optional):
   ./scripts/run_demo_stack.sh

Notes:
- Backend Start button launches: build_demo/ethical_assistant_demo
- No .NET publish step is required.
