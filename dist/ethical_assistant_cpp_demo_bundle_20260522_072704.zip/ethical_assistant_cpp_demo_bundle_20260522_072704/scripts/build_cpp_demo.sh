#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "${ROOT_DIR}/build_demo"
cd "${ROOT_DIR}/build_demo"
cmake .
make -j"$(nproc)"
echo "C++ demo build done: ${ROOT_DIR}/build_demo/ethical_assistant_demo"
