#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "[1/3] Build C++ demo"
"${ROOT_DIR}/scripts/build_cpp_demo.sh"

echo "[2/3] Start backend API in background"
(
  export Recorder__ExecutablePath="${ROOT_DIR}/build_demo/ethical_assistant_demo"
  export Recorder__WorkingDirectory="${ROOT_DIR}"
  cd "${ROOT_DIR}/demo_hybrid/RecorderBridge.Api"
  dotnet run
) &
API_PID=$!

echo "Backend PID: ${API_PID}"
echo "[3/3] Start frontend (Ctrl+C to stop; backend will be stopped too)"
trap 'kill ${API_PID} >/dev/null 2>&1 || true' EXIT
cd "${ROOT_DIR}/demo_hybrid/recorder-ui"
npm install
npm run dev
