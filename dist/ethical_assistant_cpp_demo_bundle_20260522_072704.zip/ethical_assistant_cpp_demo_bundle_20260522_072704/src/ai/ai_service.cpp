#include "ai_service.h"
#include <curl/curl.h>
#include <iostream>
#include <sstream>
#include <thread>
#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

struct AIService::Impl {
    ServiceType service_type;
    std::string api_key;
    AICallback callback;
};

AIService::AIService(ServiceType service, const std::string& api_key)
    : impl_(new Impl()) {
    impl_->service_type = service;
    impl_->api_key = api_key;

    // Try to get API key from environment if not provided
    if (impl_->api_key.empty() && service == ServiceType::GEMINI) {
        const char* env_key = std::getenv("OPENROUTER_API_KEY");
        if (env_key) {
            impl_->api_key = std::string(env_key);
        }
    }
}

AIService::~AIService() {
    delete impl_;
}

void AIService::set_service_type(ServiceType service) {
    impl_->service_type = service;
}

void AIService::set_api_key(const std::string& key) {
    impl_->api_key = key;
}

static size_t append_to_string(void* ptr, size_t size, size_t nmemb, void* userdata) {
    std::string* s = static_cast<std::string*>(userdata);
    s->append(static_cast<char*>(ptr), size * nmemb);
    return size * nmemb;
}

bool AIService::check_service_available(ServiceType service, const std::string& api_key) {
    if (service == ServiceType::GEMINI && api_key.empty()) {
        std::cerr << "[AIService] OpenRouter API key not provided for availability check." << std::endl;
        return false;
    }

    if (service == ServiceType::GEMINI) {
        CURL* curl = curl_easy_init();
        if (!curl) return false;

        std::string url = "https://openrouter.ai/api/v1/models";
        
        struct curl_slist* headers = nullptr;
        headers = curl_slist_append(headers, "Content-Type: application/json");
        std::string auth_header = "Authorization: Bearer " + api_key;
        headers = curl_slist_append(headers, auth_header.c_str());
        
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 5L);

        std::string response;
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, append_to_string);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

        CURLcode res = curl_easy_perform(curl);
        curl_slist_free_all(headers);
        curl_easy_cleanup(curl);

        return (res == CURLE_OK && !response.empty());
    }

    return true; // MOCK is always available
}

std::string AIService::query_gemini(const std::string& prompt) {
    std::cout << "[AIService DEBUG] Attempting to use API Key: '" << impl_->api_key << "'" << std::endl;

    if (impl_->api_key.empty()) {
        std::cerr << "[AIService] OpenRouter API key not set. Cannot make a request." << std::endl;
        return "";
    }

    CURL* curl = curl_easy_init();
    if (!curl) {
        std::cerr << "[AIService] Failed to initialize cURL." << std::endl;
        return "";
    }

    // OpenRouter endpoint for chat completions with streaming
    std::string url = "https://openrouter.ai/api/v1/chat/completions";
    
    // Build the request body in OpenAI chat format with streaming enabled
    json body;
    body["model"] = "openai/gpt-4o-mini";  // Fast model: ~2-3s response time
    body["stream"] = true;  // Enable streaming!
    body["messages"] = json::array();
    
    // Add system prompt to enforce behavior based on [INSTRUCTION] tags in the prompt
    std::string system_prompt = "You are a helpful assistant. Your responses must strictly follow any [INSTRUCTION] tags provided by the user. "
                                "When [INSTRUCTION] specifies 'ONLY', 'just', or 'no explanations', you MUST comply exactly. "
                                "Do not add analysis, explanations, comments, or markdown formatting unless explicitly requested. "
                                "Return ONLY what is asked for.";
    
    body["messages"].push_back({
        {"role", "system"},
        {"content", system_prompt}
    });
    
    body["messages"].push_back({
        {"role", "user"},
        {"content", prompt}
    });

    std::string body_str = body.dump();

    // Set up headers with Authorization
    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    std::string auth_header = "Authorization: Bearer " + impl_->api_key;
    headers = curl_slist_append(headers, auth_header.c_str());
    
    // Optional headers for OpenRouter rankings
    headers = curl_slist_append(headers, "HTTP-Referer: https://localhost");
    headers = curl_slist_append(headers, "X-Title: AI Service Local App");

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body_str.c_str());

    std::string response_str;
    // Reserve space to avoid repeated reallocations
    response_str.reserve(100000); // Reserve 100KB
    
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, append_to_string);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_str);

    CURLcode res = curl_easy_perform(curl);

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) {
        std::cerr << "[AIService] OpenRouter query failed with cURL error: " << curl_easy_strerror(res) << std::endl;
        return "";
    }

    // Parse Server-Sent Events (SSE) stream
    // Each line starting with "data: " contains a JSON chunk
    std::string full_response;
    full_response.reserve(50000); // Reserve space for the final response
    
    std::istringstream stream(response_str);
    std::string line;
    
    // Add safety limit to prevent infinite memory growth
    const size_t MAX_RESPONSE_SIZE = 1000000; // 1MB limit
    
    while (std::getline(stream, line)) {
        if (line.empty() || line == ":") continue;
        
        // Safety check
        if (full_response.size() > MAX_RESPONSE_SIZE) {
            std::cerr << "[AIService] Response exceeded maximum size limit" << std::endl;
            break;
        }
        
        // Lines starting with "data: " contain the JSON chunks
        if (line.find("data: ") == 0) {
            std::string json_str = line.substr(6); // Remove "data: " prefix
            
            if (json_str == "[DONE]") {
                break; // Stream finished
            }
            
            try {
                json json_chunk = json::parse(json_str);
                
                // Extract the delta content from the chunk
                if (json_chunk.contains("choices") && 
                    json_chunk["choices"].is_array() && 
                    !json_chunk["choices"].empty()) {
                    
                    const auto& choice = json_chunk["choices"][0];
                    if (choice.contains("delta") && choice["delta"].contains("content")) {
                        std::string content = choice["delta"]["content"].get<std::string>();
                        
                        // Safety check on individual chunks
                        if (content.size() < 10000) { // Sanity check per chunk
                            full_response += content;
                            
                            // Call callback with chunk for streaming display (UI will buffer these)
                            if (impl_->callback) {
                                impl_->callback(content, false); // false = not final
                            }
                        }
                    }
                }
            } catch (const json::parse_error& e) {
                // Skip malformed JSON chunks
                std::cerr << "[AIService] JSON parse error: " << e.what() << std::endl;
                continue;
            } catch (const std::exception& e) {
                std::cerr << "[AIService] Exception during parsing: " << e.what() << std::endl;
                continue;
            }
        }
    }
    
    std::cout << "[AIService] Total response size: " << full_response.size() << " bytes" << std::endl;
    
    return full_response;
}

std::string AIService::query_mock(const std::string& prompt) {
    std::cout << "[AIService] Using MOCK service (no network calls)" << std::endl;
    
    if (prompt.find("screenshot") != std::string::npos || 
        prompt.find("OCR") != std::string::npos) {
        return "Mock response: This screenshot contains clearly visible text. The OCR extraction was successful.";
    } else if (prompt.find("transcri") != std::string::npos ||
               prompt.find("recording") != std::string::npos ||
               prompt.find("audio") != std::string::npos) {
        return "Mock response: The audio recording quality is excellent. The transcript has been accurately generated.";
    }
    
    return "Mock response: Analysis complete. This is a test response from the mock service.";
}

bool AIService::analyze_text(const std::string& text, AICallback cb) {
    impl_->callback = cb;

    std::thread([this, text]() {
        std::string prompt = "Analyze and summarize this text:\n\n" + text;
        std::string response;

        switch (impl_->service_type) {
            case ServiceType::GEMINI:
                response = query_gemini(prompt);
                break;
            case ServiceType::MOCK:
                response = query_mock(prompt);
                break;
        }

        bool success = !response.empty();
        std::cout << "[AIService] Text analysis: " << (success ? "SUCCESS" : "FAILED") << std::endl;

        if (impl_->callback) {
            impl_->callback(response, success);
        }
    }).detach();

    return true;
}

bool AIService::ask_question(const std::string& question, AICallback cb) {
    impl_->callback = cb;

    std::thread([this, question]() {
        std::string response;

        switch (impl_->service_type) {
            case ServiceType::GEMINI:
                response = query_gemini(question);
                break;
            case ServiceType::MOCK:
                response = query_mock(question);
                break;
        }

        bool success = !response.empty();
        std::cout << "[AIService] Question response: " << (success ? "SUCCESS" : "FAILED") << std::endl;

        if (impl_->callback) {
            impl_->callback(response, success);
        }
    }).detach();

    return true;
}

std::string AIService::get_gemini_api_key() {
    const char* key = std::getenv("OPENROUTER_API_KEY");
    return key ? std::string(key) : "";
}