#include "openai_client.h"
#include <curl/curl.h>
#include <iostream>
#include <fstream>
#include <sstream>

OpenAIClient::OpenAIClient(const std::string &api_key, const std::string &endpoint_base)
    : api_key_(api_key), endpoint_base_(endpoint_base) {
    // Example: endpoint_base could be "https://api.openai.com/v1"
}

static size_t append_to_string(void* ptr, size_t size, size_t nmemb, void* userdata) {
    std::string* s = static_cast<std::string*>(userdata);
    s->append(static_cast<char*>(ptr), size * nmemb);
    return size * nmemb;
}

std::string OpenAIClient::transcribe_audio_file(const std::string &filepath) {
    if (api_key_.empty() || endpoint_base_.empty()) return "";

    std::string url = endpoint_base_ + "/audio/transcriptions"; // adapt to provider
    CURL *curl = curl_easy_init();
    if (!curl) return "";

    struct curl_slist *headers = nullptr;
    std::string auth = "Authorization: Bearer " + api_key_;
    headers = curl_slist_append(headers, auth.c_str());

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

    // Build multipart/form-data
    curl_mime *mime = curl_mime_init(curl);
    curl_mimepart *part = curl_mime_addpart(mime);
    curl_mime_name(part, "file");
    curl_mime_filedata(part, filepath.c_str());

    curl_easy_setopt(curl, CURLOPT_MIMEPOST, mime);

    std::string response;
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, append_to_string);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

    CURLcode res = curl_easy_perform(curl);
    if (res != CURLE_OK) {
        std::cerr << "OpenAI transcribe error: " << curl_easy_strerror(res) << std::endl;
    }

    curl_mime_free(mime);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    return response; // in practice you'd parse JSON and return the "text" field
}

std::string OpenAIClient::chat_completion(const std::string &prompt) {
    if (api_key_.empty() || endpoint_base_.empty()) return "";

    std::string url = endpoint_base_ + "/chat/completions"; // adapt to provider
    CURL *curl = curl_easy_init();
    if (!curl) return "";

    struct curl_slist *headers = nullptr;
    std::string auth = "Authorization: Bearer " + api_key_;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, auth.c_str());

    // Build a minimal JSON body (adjust model name and fields)
    std::ostringstream body;
    body << R"({"model":"gpt-4o-mini","messages":[{"role":"user","content":")" << prompt << R"("}]})";
    std::string body_str = body.str();

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body_str.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, body_str.size());

    std::string response;
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, append_to_string);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

    CURLcode res = curl_easy_perform(curl);
    if (res != CURLE_OK) {
        std::cerr << "OpenAI chat error: " << curl_easy_strerror(res) << std::endl;
    }

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    return response; // parse JSON in production; this returns raw response
}
