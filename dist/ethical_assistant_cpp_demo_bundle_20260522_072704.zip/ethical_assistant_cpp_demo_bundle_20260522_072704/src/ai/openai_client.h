#pragma once
#include <string>

class OpenAIClient {
public:
    OpenAIClient(const std::string &api_key, const std::string &endpoint_base = "");

    // Example: transcribe a local audio file (blocking). Returns text or empty string on error.
    std::string transcribe_audio_file(const std::string &filepath);

    // Example chat completion call (blocking). Returns model text response or empty string.
    std::string chat_completion(const std::string &prompt);

private:
    std::string api_key_;
    std::string endpoint_base_;
};
