#pragma once
// ai_service.h
// Free AI integration using Google Gemini or Mock service

#include <string>
#include <functional>

using AICallback = std::function<void(const std::string& response, bool success)>;

class AIService {
public:
    // Service type enum
    enum class ServiceType {
        GEMINI,  // Google Gemini API (FREE tier)
        MOCK     // Mock for testing (no network needed)
    };

    AIService(ServiceType service = ServiceType::GEMINI, 
              const std::string& api_key = "");
    ~AIService();

    // Analyze text (OCR output or transcript)
    // Runs in background thread, calls callback with result
    bool analyze_text(const std::string& text, AICallback cb = nullptr);

    // Chat completion
    bool ask_question(const std::string& question, AICallback cb = nullptr);

    // Check if service is available
    static bool check_service_available(ServiceType service, const std::string& api_key);

    // Set service type
    void set_service_type(ServiceType service);

    // Set API key
    void set_api_key(const std::string& key);

    // Get Gemini API key from environment
    static std::string get_gemini_api_key();

private:
    struct Impl;
    Impl* impl_;

    // Helper methods
    std::string query_gemini(const std::string& prompt);
    std::string query_mock(const std::string& prompt);
};

