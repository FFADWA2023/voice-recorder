#pragma once
#include <string>
#include <map>

class AppConfig {
public:
    AppConfig() = default;
    ~AppConfig() = default;

    // Load configuration from JSON file
    bool load_from_file(const std::string& path);

    std::string get_string(const std::string& key, const std::string& def = "") const;
    int get_int(const std::string& key, int def = 0) const;
    bool get_bool(const std::string& key, bool def = false) const;

private:
    std::map<std::string, std::string> string_values_;
    std::map<std::string, int> int_values_;
    std::map<std::string, bool> bool_values_;
};
