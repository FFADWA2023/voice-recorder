// analyze_with_deepseek.cpp
// Find latest txt file (audio or screenshot), send to DeepSeek via OpenRouter, save result

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <filesystem>
#include <cstdlib>
#include <algorithm>
#include <curl/curl.h>
#include <chrono>
#include <nlohmann/json.hpp>

namespace fs = std::filesystem;

std::string get_latest_txt(const std::vector<std::string>& dirs) {
    fs::path latest_file;
    std::chrono::system_clock::time_point latest_time;
    bool found = false;
    std::uintmax_t latest_time_count = 0;
    for (const auto& dir : dirs) {
        for (const auto& entry : fs::directory_iterator(dir)) {
            if (entry.is_regular_file() && entry.path().extension() == ".txt") {
                auto ftime = fs::last_write_time(entry.path());
                auto ftime_count = ftime.time_since_epoch().count();
                if (!found || ftime_count > latest_time_count) {
                    latest_file = entry.path();
                    latest_time_count = ftime_count;
                    found = true;
                }
            }
        }
    }
    return found ? latest_file.string() : "";
}

size_t write_callback(void* ptr, size_t size, size_t nmemb, void* userdata) {
    std::string* s = static_cast<std::string*>(userdata);
    s->append(static_cast<char*>(ptr), size * nmemb);
    return size * nmemb;
}

int main() {
    std::vector<std::string> txt_dirs = {
        "/home/dell/recordings/audio_txt",
        "/home/dell/recordings/screenshot_txt"
    };
    std::string latest_txt = get_latest_txt(txt_dirs);
    if (latest_txt.empty()) {
        std::cerr << "No txt files found." << std::endl;
        return 1;
    }
    std::cout << "Latest txt file: " << latest_txt << std::endl;

    std::ifstream infile(latest_txt);
    if (!infile) {
        std::cerr << "Failed to open txt file." << std::endl;
        return 1;
    }
    std::string text((std::istreambuf_iterator<char>(infile)), std::istreambuf_iterator<char>());
    infile.close();

    // Prompt style menu
    std::cout << "Choose DeepSeek prompt style:\n";
    std::cout << "1. Format as Markdown with code blocks and explanations\n";
    std::cout << "2. Step-by-step: corrected code, explanation, sample output\n";
    std::cout << "3. Only output corrected code, nothing else\n";
    std::cout << "4. Run the code and give me the result of the function\n";
    std::cout << "Enter 1, 2, 3 or 4: ";
    int choice = 1;
    std::cin >> choice;

    std::string prompt_prefix;
    switch (choice) {
        case 1:
            prompt_prefix = "Please format your response as Markdown with code blocks and explanations.\n";
            break;
        case 2:
            prompt_prefix = "First, show the corrected code. Then, explain the changes. Finally, provide sample output as if the code was executed.\n";
            break;
        case 3:
            prompt_prefix = "Only output the corrected code, nothing else.\n";
            break;
        case 4:
            prompt_prefix = "Run the code in java compiler and give me the result of the function.\n";
            break;
        default:
            prompt_prefix = "Please format your response as Markdown with code blocks and explanations.\n";
            break;
    }

    std::string full_prompt = prompt_prefix + text;

    const char* api_key = std::getenv("OPENROUTER_API_KEY");
    if (!api_key) {
        std::cerr << "OPENROUTER_API_KEY not set in environment." << std::endl;
        return 1;
    }

    std::string url = "https://openrouter.ai/api/v1/chat/completions";

    // Build JSON payload using nlohmann::json for OpenAI chat format
    nlohmann::json message = nlohmann::json::object();
    message["role"] = "user";
    message["content"] = full_prompt;

    nlohmann::json body = nlohmann::json::object();
    body["model"] = "tngtech/deepseek-r1t2-chimera:free";
    body["messages"] = nlohmann::json::array({ message });

    std::string json_body = body.dump();

    // Print the request body to stdout for debugging
    std::cout << "--- OpenRouter request body (truncated 10k chars) ---\n";
    if (json_body.size() > 10000) {
        std::cout << json_body.substr(0, 10000) << "\n...[truncated]...\n";
    } else {
        std::cout << json_body << std::endl;
    }

    CURL* curl = curl_easy_init();
    if (!curl) {
        std::cerr << "Failed to initialize curl." << std::endl;
        return 1;
    }

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    std::string auth_header = std::string("Authorization: Bearer ") + api_key;
    headers = curl_slist_append(headers, auth_header.c_str());
    headers = curl_slist_append(headers, "HTTP-Referer: https://github.com/yourusername/yourproject");
    headers = curl_slist_append(headers, "X-Title: AI Service App");

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, json_body.c_str());
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 60L);

    std::string response;
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

    CURLcode res = curl_easy_perform(curl);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) {
        std::cerr << "OpenRouter API error: " << curl_easy_strerror(res) << std::endl;
        return 1;
    }

    std::string results_dir = "/home/dell/recordings/deepseek_results";
    fs::create_directories(results_dir);
    auto now = std::chrono::system_clock::now();
    std::time_t t = std::chrono::system_clock::to_time_t(now);
    char fname[128];
    std::strftime(fname, sizeof(fname), "ai_result_%Y%m%d_%H%M%S.txt", std::localtime(&t));
    std::string result_file = results_dir + "/" + fname;

    std::ofstream outfile(result_file);
    if (!outfile) {
        std::cerr << "Failed to write result file." << std::endl;
        return 1;
    }
    outfile << response;
    outfile.close();
    std::cout << "DeepSeek result saved to: " << result_file << std::endl;
    return 0;
}