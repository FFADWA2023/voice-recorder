#include "screen_capture.h"
#include <gst/gst.h>
#include <gst/app/gstappsink.h>
#include <thread>
#include <mutex>
#include <iostream>

// Implementation struct
struct ScreenCapture::Impl {
    GstElement* pipeline = nullptr;
    GstElement* appsink = nullptr;
    ScreenFrameCallback callback;
    std::mutex cb_mutex;
};

// Constructor: initialize GStreamer
ScreenCapture::ScreenCapture() : impl_(std::make_unique<Impl>()), running_(false) {
    gst_init(nullptr, nullptr); // safe to call multiple times
}

// Destructor: stop pipeline
ScreenCapture::~ScreenCapture() {
    stop();
}

// Appsink callback for new video frames
static GstFlowReturn on_new_sample(GstAppSink* appsink, gpointer user_data) {
    ScreenCapture::Impl* impl = static_cast<ScreenCapture::Impl*>(user_data);
    std::lock_guard<std::mutex> lock(impl->cb_mutex);

    GstSample* sample = gst_app_sink_pull_sample(appsink);
    if (!sample) return GST_FLOW_OK;

    GstCaps* caps = gst_sample_get_caps(sample);
    GstStructure* s = gst_caps_get_structure(caps, 0);
    int width = 0, height = 0;
    gst_structure_get_int(s, "width", &width);
    gst_structure_get_int(s, "height", &height);

    GstBuffer* buffer = gst_sample_get_buffer(sample);
    GstMapInfo map;
    if (gst_buffer_map(buffer, &map, GST_MAP_READ)) {
        uint64_t pts_ms = (GST_BUFFER_PTS(buffer) == GST_CLOCK_TIME_NONE) ? 0 :
                          (GST_BUFFER_PTS(buffer) / GST_MSECOND);

        if (impl->callback) {
            impl->callback(map.data, map.size, width, height, pts_ms);
        }
        gst_buffer_unmap(buffer, &map);
    }

    gst_sample_unref(sample);
    return GST_FLOW_OK;
}

// Start screen capture
bool ScreenCapture::start(ScreenFrameCallback cb) {
    if (running_.load()) return true;

    impl_->callback = cb;

    const char* pipeline_desc =
        "ximagesrc use-damage=0 ! video/x-raw,format=RGB,width=1280,height=720,framerate=30/1 ! "
        "videoconvert ! appsink name=sink";

    GError* error = nullptr;
    impl_->pipeline = gst_parse_launch(pipeline_desc, &error);
    if (!impl_->pipeline) {
        std::cerr << "Failed to create GStreamer pipeline: "
                  << (error ? error->message : "unknown") << std::endl;
        if (error) g_error_free(error);
        return false;
    }

    impl_->appsink = gst_bin_get_by_name(GST_BIN(impl_->pipeline), "sink");
    if (!impl_->appsink) {
        std::cerr << "Failed to get appsink element\n";
        gst_object_unref(impl_->pipeline);
        impl_->pipeline = nullptr;
        return false;
    }

    gst_app_sink_set_emit_signals(GST_APP_SINK(impl_->appsink), true);
    gst_app_sink_set_max_buffers(GST_APP_SINK(impl_->appsink), 5);
    gst_app_sink_set_drop(GST_APP_SINK(impl_->appsink), true);

    g_signal_connect(impl_->appsink, "new-sample", G_CALLBACK(on_new_sample), impl_.get());

    if (gst_element_set_state(impl_->pipeline, GST_STATE_PLAYING) == GST_STATE_CHANGE_FAILURE) {
        std::cerr << "Failed to set pipeline to PLAYING\n";
        gst_object_unref(impl_->appsink);
        gst_object_unref(impl_->pipeline);
        impl_->appsink = nullptr;
        impl_->pipeline = nullptr;
        return false;
    }

    running_.store(true);
    return true;
}

// Stop screen capture
void ScreenCapture::stop() {
    if (!running_.load()) return;

    if (impl_->pipeline) {
        gst_element_set_state(impl_->pipeline, GST_STATE_NULL);
        gst_object_unref(impl_->appsink);
        gst_object_unref(impl_->pipeline);
        impl_->appsink = nullptr;
        impl_->pipeline = nullptr;
    }

    running_.store(false);
}
