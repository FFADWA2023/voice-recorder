#include "screenshot_capture.h"
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <thread>
#include <unistd.h>

struct ScreenshotCapture::Impl {
    ScreenshotCallback callback;
};

ScreenshotCapture::ScreenshotCapture() : impl_(std::make_unique<Impl>()) {}

ScreenshotCapture::~ScreenshotCapture() = default;

bool ScreenshotCapture::is_available() {
    // Prefer maim (silent, customizable) if installed
    if (system("which maim > /dev/null 2>&1") == 0) return true;
    // Fall back to gnome-screenshot if necessary
    if (system("which gnome-screenshot > /dev/null 2>&1") == 0) return true;
    return false;
}

bool ScreenshotCapture::capture_screen(const std::string& output_path, ScreenshotCallback cb) {
    impl_->callback = cb;

    // Run screenshot capture in background thread to avoid blocking UI
    std::thread([this, output_path]() {
        std::ostringstream cmd;
        bool success = false;

        // Use maim for full-screen if available
        if (system("which maim > /dev/null 2>&1") == 0) {
            // maim outputs PNG to stdout; redirect to file with shell
            cmd << "maim -b 0 -c 0,0,0,0 -u > '" << output_path << "' 2>/dev/null";
        } else {
            // Fallback
            cmd << "gnome-screenshot -f '" << output_path << "' 2>/dev/null";
        }

        int ret = system(cmd.str().c_str());
        success = (ret == 0);

        std::cout << "[ScreenshotCapture] Full screen capture: " 
                  << (success ? "SUCCESS" : "FAILED") 
                  << " -> " << output_path << std::endl;

        if (impl_->callback) {
            impl_->callback(output_path, success);
        }
    }).detach();

    return true;
}

bool ScreenshotCapture::capture_area(const std::string& output_path, ScreenshotCallback cb) {
    impl_->callback = cb;

    // Run area selection in background thread
    std::thread([this, output_path]() {
        // small delay to ensure caller had time to hide UI if needed
        usleep(120000);

        std::ostringstream cmd;
        bool success = false;

        // Use maim -s for interactive selection
        if (system("which maim > /dev/null 2>&1") == 0) {
            // maim -s outputs PNG to stdout; redirect to file with shell
            cmd << "maim -s -b 0 -c 0,0,0,0 -u > '" << output_path << "' 2>/dev/null";
        } else {
            // Fallback to gnome-screenshot area selection
            cmd << "gnome-screenshot -a -f '" << output_path << "' 2>/dev/null";
        }

        int ret = system(cmd.str().c_str());
        success = (ret == 0);

        std::cout << "[ScreenshotCapture] Area selection capture: " 
                  << (success ? "SUCCESS" : "FAILED") 
                  << " -> " << output_path << std::endl;

        if (impl_->callback) {
            impl_->callback(output_path, success);
        }
    }).detach();

    return true;
}