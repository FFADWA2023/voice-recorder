#pragma once
// screenshot_capture.h
// Simple screenshot capture using gnome-screenshot

#include <string>
#include <functional>
#include <memory>

using ScreenshotCallback = std::function<void(const std::string& filepath, bool success)>;

class ScreenshotCapture {
public:
    ScreenshotCapture();
    ~ScreenshotCapture();

    // Capture entire screen - saves to output_path
    // Calls callback with filepath and success status
    bool capture_screen(const std::string& output_path, ScreenshotCallback cb = nullptr);

    // Capture selected area - shows selection UI
    // Calls callback with filepath and success status
    bool capture_area(const std::string& output_path, ScreenshotCallback cb = nullptr);

    // Check if gnome-screenshot is available
    static bool is_available();

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
