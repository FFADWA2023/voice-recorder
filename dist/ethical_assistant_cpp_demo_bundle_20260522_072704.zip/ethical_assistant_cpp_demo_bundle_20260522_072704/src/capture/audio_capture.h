#pragma once

#include <functional>
#include <cstdint>
#include <atomic>
#include <memory>
#include <mutex>

// Callback type for raw audio frames
using AudioFrameCallback = std::function<void(const uint8_t* data, size_t length, uint64_t pts_ms)>;

class AudioCapture {
public:
    struct Impl;  // Forward declaration of the implementation struct

    AudioCapture();
    ~AudioCapture();

    // Start audio capture; returns true if the pipeline started successfully
    bool start(AudioFrameCallback cb);

    // Stop audio capture
    void stop();

    // Returns true if the pipeline is running
    bool is_running() const { return running_.load(); }

    // Expose Impl pointer if needed externally
    Impl* get_impl() { return impl_.get(); }

private:
    std::unique_ptr<Impl> impl_;  // PIMPL pointer
    std::atomic<bool> running_;   // Tracks if pipeline is running
};
