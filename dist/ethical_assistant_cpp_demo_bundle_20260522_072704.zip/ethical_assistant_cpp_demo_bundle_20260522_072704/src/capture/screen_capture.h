#pragma once

#include <functional>
#include <cstdint>
#include <atomic>
#include <memory>
#include <mutex>

// Callback type for raw screen frames (RGB32)
using ScreenFrameCallback = std::function<void(const uint8_t* data, size_t length,
                                               int width, int height, uint64_t pts_ms)>;

class ScreenCapture {
public:
    struct Impl; // forward declaration

    ScreenCapture();
    ~ScreenCapture();

    // Start screen capture; returns true if pipeline started successfully
    bool start(ScreenFrameCallback cb);

    // Stop screen capture
    void stop();

    bool is_running() const { return running_.load(); }

    // Expose Impl pointer if needed externally
    Impl* get_impl() { return impl_.get(); }

private:
    std::unique_ptr<Impl> impl_;
    std::atomic<bool> running_;
};
