#include "audio_capture.h"
#include <gst/gst.h>
#include <gst/app/gstappsink.h>
#include <thread>
#include <mutex>
#include <iostream>

// Implementation struct
struct AudioCapture::Impl {
    GstElement* pipeline = nullptr;
    GstElement* appsink = nullptr;
    AudioFrameCallback callback;
    std::mutex cb_mutex;
};

// Constructor: initialize GStreamer and Impl
AudioCapture::AudioCapture() : impl_(std::make_unique<Impl>()), running_(false) {
    gst_init(nullptr, nullptr);  // Safe to call multiple times
}

// Destructor: stop pipeline and release resources
AudioCapture::~AudioCapture() {
    stop();
}

// Appsink callback for new audio samples
static GstFlowReturn on_new_sample(GstAppSink* appsink, gpointer user_data) {
    AudioCapture::Impl* impl = static_cast<AudioCapture::Impl*>(user_data);
    std::lock_guard<std::mutex> lock(impl->cb_mutex);

    GstSample* sample = gst_app_sink_pull_sample(appsink);
    if (!sample) return GST_FLOW_OK;

    GstBuffer* buffer = gst_sample_get_buffer(sample);
    GstMapInfo map;
    if (gst_buffer_map(buffer, &map, GST_MAP_READ)) {
        uint64_t pts_ms = (GST_BUFFER_PTS(buffer) == GST_CLOCK_TIME_NONE) ? 0 :
                          (GST_BUFFER_PTS(buffer) / GST_MSECOND);
        if (impl->callback) {
            impl->callback(reinterpret_cast<const uint8_t*>(map.data), map.size, pts_ms);
        }
        gst_buffer_unmap(buffer, &map);
    }
    gst_sample_unref(sample);
    return GST_FLOW_OK;
}

// Start audio capture pipeline
bool AudioCapture::start(AudioFrameCallback cb) {
    if (running_.load()) return true;

    impl_->callback = cb;

    // Build pipeline: Use 48000Hz and 2 channels (supported by Opus codec)
    GError* error = nullptr;
    const char* pipeline_desc =
        "autoaudiosrc ! audioconvert ! audioresample ! audio/x-raw,format=S16LE,channels=2,rate=48000 ! appsink name=sink";

    impl_->pipeline = gst_parse_launch(pipeline_desc, &error);
    if (!impl_->pipeline) {
        std::cerr << "Failed to create GStreamer pipeline: "
                  << (error ? error->message : "unknown") << std::endl;
        if (error) g_error_free(error);
        return false;
    }

    impl_->appsink = gst_bin_get_by_name(GST_BIN(impl_->pipeline), "sink");
    if (!impl_->appsink) {
        std::cerr << "Failed to get appsink element\n";
        gst_object_unref(impl_->pipeline);
        impl_->pipeline = nullptr;
        return false;
    }

    gst_app_sink_set_emit_signals(GST_APP_SINK(impl_->appsink), true);
    gst_app_sink_set_max_buffers(GST_APP_SINK(impl_->appsink), 5);
    gst_app_sink_set_drop(GST_APP_SINK(impl_->appsink), true);

    g_signal_connect(impl_->appsink, "new-sample", G_CALLBACK(on_new_sample), impl_.get());

    if (gst_element_set_state(impl_->pipeline, GST_STATE_PLAYING) == GST_STATE_CHANGE_FAILURE) {
        std::cerr << "Failed to set pipeline to PLAYING\n";
        gst_object_unref(impl_->appsink);
        gst_object_unref(impl_->pipeline);
        impl_->appsink = nullptr;
        impl_->pipeline = nullptr;
        return false;
    }

    running_.store(true);
    return true;
}

// Stop audio capture pipeline
void AudioCapture::stop() {
    if (!running_.load()) return;

    if (impl_->pipeline) {
        gst_element_set_state(impl_->pipeline, GST_STATE_NULL);
        gst_object_unref(impl_->appsink);
        gst_object_unref(impl_->pipeline);
        impl_->appsink = nullptr;
        impl_->pipeline = nullptr;
    }

    running_.store(false);
}
