#pragma once
#include <cstdint>
#include <string>

class AudioEncoder {
public:
    AudioEncoder();
    ~AudioEncoder();

    // Initialize Opus encoder and container output
    bool init(const std::string& output_filename, int sample_rate = 16000, int channels = 1);

    // Encode a chunk of PCM 16-bit audio
    bool encode(const uint8_t* pcm_data, size_t length);

    // Finalize file and flush encoder
    void finalize();

private:
    struct Impl;
    Impl* impl_;
};
