#pragma once
#include <cstdint>
#include <string>

class VideoEncoder {
public:
    VideoEncoder();
    ~VideoEncoder();

    // Initialize H.264 encoder and container output
    bool init(const std::string& output_filename, int width, int height, int fps = 30);

    // Encode a single RGB32 frame
    bool encode_frame(const uint8_t* rgb_data);

    // Finalize file and flush encoder
    void finalize();

private:
    struct Impl;
    Impl* impl_;
};
