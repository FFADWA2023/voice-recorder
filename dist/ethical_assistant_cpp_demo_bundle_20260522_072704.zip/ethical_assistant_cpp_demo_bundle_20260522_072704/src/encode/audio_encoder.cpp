#include "audio_encoder.h"
#include <iostream>
#include <fstream>
#include <cstring>

// Simple WAV file header
struct WAVHeader {
    char riff[4] = {'R', 'I', 'F', 'F'};
    uint32_t file_size;
    char wave[4] = {'W', 'A', 'V', 'E'};
    
    char fmt[4] = {'f', 'm', 't', ' '};
    uint32_t fmt_size = 16;
    uint16_t audio_format = 1; // PCM
    uint16_t num_channels;
    uint32_t sample_rate;
    uint32_t byte_rate;
    uint16_t block_align;
    uint16_t bits_per_sample = 16;
    
    char data[4] = {'d', 'a', 't', 'a'};
    uint32_t data_size;
};

struct AudioEncoder::Impl {
    std::ofstream file;
    int sample_rate = 0;
    int channels = 0;
    uint32_t data_size = 0;
    bool initialized = false;
};

AudioEncoder::AudioEncoder() : impl_(new Impl()) {}
AudioEncoder::~AudioEncoder() { finalize(); delete impl_; }

bool AudioEncoder::init(const std::string& output_filename, int sample_rate, int channels) {
    if (impl_->initialized) {
        finalize();
    }

    impl_->sample_rate = sample_rate;
    impl_->channels = channels;
    impl_->data_size = 0;

    // Open file for writing
    impl_->file.open(output_filename, std::ios::binary);
    if (!impl_->file.is_open()) {
        std::cerr << "Failed to open output file: " << output_filename << "\n";
        return false;
    }

    // Write WAV header (we'll update file_size and data_size at finalize)
    WAVHeader header;
    header.num_channels = channels;
    header.sample_rate = sample_rate;
    header.byte_rate = sample_rate * channels * 2; // 2 bytes per sample (16-bit)
    header.block_align = channels * 2;
    header.file_size = 36; // Will update later
    header.data_size = 0; // Will update later

    impl_->file.write((char*)&header, sizeof(WAVHeader));
    if (!impl_->file.good()) {
        std::cerr << "Failed to write WAV header\n";
        impl_->file.close();
        return false;
    }

    impl_->initialized = true;
    std::cerr << "✓ Audio file initialized: " << output_filename << " (" << sample_rate 
              << "Hz, " << channels << "ch)\n";
    return true;
}

bool AudioEncoder::encode(const uint8_t* pcm_data, size_t length) {
    if (!impl_->initialized || !impl_->file.is_open()) {
        return false;
    }

    // Simply write raw PCM data
    impl_->file.write((const char*)pcm_data, length);
    if (!impl_->file.good()) {
        std::cerr << "Failed to write audio data\n";
        return false;
    }

    impl_->data_size += length;
    return true;
}

void AudioEncoder::finalize() {
    if (!impl_->initialized || !impl_->file.is_open()) {
        return;
    }

    // Update file header with actual sizes
    uint32_t file_size = 36 + impl_->data_size;
    impl_->file.seekp(4);
    impl_->file.write((char*)&file_size, 4);

    impl_->file.seekp(40);
    impl_->file.write((char*)&impl_->data_size, 4);

    impl_->file.close();
    std::cerr << "✓ Audio file saved: " << impl_->data_size << " bytes of audio data\n";

    impl_->initialized = false;
    impl_->data_size = 0;
}
