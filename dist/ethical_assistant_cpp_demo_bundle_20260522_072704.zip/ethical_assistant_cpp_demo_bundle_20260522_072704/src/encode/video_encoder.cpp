#include "video_encoder.h"
#include <iostream>
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/opt.h>
#include <libavutil/imgutils.h>
#include <libswscale/swscale.h>
}

struct VideoEncoder::Impl {
    AVFormatContext* fmt_ctx = nullptr;
    AVStream* video_stream = nullptr;
    AVCodecContext* codec_ctx = nullptr;
    SwsContext* sws_ctx = nullptr;
    AVFrame* frame = nullptr;
    int64_t pts = 0;
};

VideoEncoder::VideoEncoder() : impl_(new Impl()) {}
VideoEncoder::~VideoEncoder() { finalize(); delete impl_; }

bool VideoEncoder::init(const std::string& output_filename, int width, int height, int fps) {
    avformat_alloc_output_context2(&impl_->fmt_ctx, nullptr, nullptr, output_filename.c_str());
    if (!impl_->fmt_ctx) { std::cerr << "Failed to create output context\n"; return false; }

    AVCodec* codec = avcodec_find_encoder(AV_CODEC_ID_H264);
    if (!codec) { std::cerr << "H.264 codec not found\n"; return false; }

    impl_->video_stream = avformat_new_stream(impl_->fmt_ctx, nullptr);
    if (!impl_->video_stream) { std::cerr << "Failed to create video stream\n"; return false; }

    impl_->codec_ctx = avcodec_alloc_context3(codec);
    impl_->codec_ctx->codec_id = codec->id;
    impl_->codec_ctx->width = width;
    impl_->codec_ctx->height = height;
    impl_->codec_ctx->time_base = AVRational{1, fps};
    impl_->codec_ctx->framerate = AVRational{fps,1};
    impl_->codec_ctx->pix_fmt = AV_PIX_FMT_YUV420P;
    impl_->codec_ctx->bit_rate = 2*1000*1000; // 2 Mbps

    if (impl_->fmt_ctx->oformat->flags & AVFMT_GLOBALHEADER)
        impl_->codec_ctx->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;

    if (avcodec_open2(impl_->codec_ctx, codec, nullptr) < 0) { std::cerr << "Failed to open codec\n"; return false; }

    impl_->video_stream->time_base = impl_->codec_ctx->time_base;

    if (avio_open(&impl_->fmt_ctx->pb, output_filename.c_str(), AVIO_FLAG_WRITE) < 0) {
        std::cerr << "Failed to open output file\n"; return false;
    }

    if (avformat_write_header(impl_->fmt_ctx, nullptr) < 0) {
        std::cerr << "Failed to write header\n"; return false;
    }

    // allocate frame for conversion
    impl_->frame = av_frame_alloc();
    impl_->frame->format = impl_->codec_ctx->pix_fmt;
    impl_->frame->width = width;
    impl_->frame->height = height;
    av_frame_get_buffer(impl_->frame, 0);

    // sws context for RGB -> YUV420P
    impl_->sws_ctx = sws_getContext(width, height, AV_PIX_FMT_RGB32,
                                    width, height, AV_PIX_FMT_YUV420P,
                                    SWS_BILINEAR, nullptr, nullptr, nullptr);
    impl_->pts = 0;
    return true;
}

bool VideoEncoder::encode_frame(const uint8_t* rgb_data) {
    if (!impl_->codec_ctx || !impl_->frame || !impl_->sws_ctx) return false;

    uint8_t* in_data[1] = { const_cast<uint8_t*>(rgb_data) };
    int in_linesize[1] = { 4 * impl_->codec_ctx->width };

    sws_scale(impl_->sws_ctx, in_data, in_linesize, 0,
              impl_->codec_ctx->height, impl_->frame->data, impl_->frame->linesize);

    impl_->frame->pts = impl_->pts++;

    AVPacket pkt;
    av_init_packet(&pkt);
    pkt.data = nullptr;
    pkt.size = 0;

    if (avcodec_send_frame(impl_->codec_ctx, impl_->frame) < 0) return false;

    while (avcodec_receive_packet(impl_->codec_ctx, &pkt) == 0) {
        pkt.stream_index = impl_->video_stream->index;
        av_interleaved_write_frame(impl_->fmt_ctx, &pkt);
        av_packet_unref(&pkt);
    }
    return true;
}

void VideoEncoder::finalize() {
    if (!impl_->codec_ctx) return;
    avcodec_send_frame(impl_->codec_ctx, nullptr);
    AVPacket pkt;
    av_init_packet(&pkt);
    while (avcodec_receive_packet(impl_->codec_ctx, &pkt) == 0) {
        pkt.stream_index = impl_->video_stream->index;
        av_interleaved_write_frame(impl_->fmt_ctx, &pkt);
        av_packet_unref(&pkt);
    }

    av_write_trailer(impl_->fmt_ctx);

    if (impl_->frame) av_frame_free(&impl_->frame);
    if (impl_->sws_ctx) sws_freeContext(impl_->sws_ctx);
    if (impl_->codec_ctx) avcodec_free_context(&impl_->codec_ctx);
    if (impl_->fmt_ctx && impl_->fmt_ctx->pb) avio_closep(&impl_->fmt_ctx->pb);
    if (impl_->fmt_ctx) avformat_free_context(impl_->fmt_ctx);

    impl_->frame = nullptr;
    impl_->sws_ctx = nullptr;
    impl_->codec_ctx = nullptr;
    impl_->fmt_ctx = nullptr;
}
