#include "ui/consent_window.h"
#include "capture/audio_capture.h"
#include "capture/screen_capture.h"
#include "encode/audio_encoder.h"
#include "network/uploader.h"
#include "network/websocket_client.h"
#include "ai/openai_client.h"
#include "utils/logger.h"
#include "app_config.h"
#include <iostream>
#include <sys/stat.h>
#include <gdk/gdk.h>

int main(int argc, char** argv) {
    // Initialize GTK threading support BEFORE creating GTK objects
    gdk_threads_init();

    // Secure Gemini API key retrieval
    const char* env_key = std::getenv("OPENROUTER_API_KEY");
    if (!env_key) {
        std::cerr << "OPENROUTER_API_KEY not set in environment." << std::endl;
        return 1;
    }
    std::string gemini_api_key(env_key);
    
    // Load configuration from JSON
    AppConfig config;
    const char* config_path = getenv("ETHICS_CONFIG_PATH");
    if (!config_path) {
        config_path = "/home/dell/ethical_assistant/config/default_config.json";
    }
    
    if (!config.load_from_file(config_path)) {
        std::cerr << "Warning: Could not load config from " << config_path 
                  << ", using defaults\n";
    }

    // Get output directory from config
    std::string output_dir = config.get_string("output_dir", "/tmp/ethical_recordings");
    
    // Create output directory if it doesn't exist
    mkdir(output_dir.c_str(), 0755);

    // Initialize logger
    std::string log_file = config.get_string("log_file", output_dir + "/ethical_assistant.log");
    Logger logger(log_file);
    logger.log("=== Ethical Assistant Started ===");
    logger.log("Output directory: " + output_dir);
    logger.log("Config path: " + std::string(config_path ? config_path : "default"));

    // Initialize UI toolkit (GTK) - visible window
    ConsentWindow::init(argc, argv);

    // Create and show the consent window
    // The window will internally manage audio capture and encoding after user consent
    ConsentWindow window(&config, &logger);
    window.show();
    logger.log("Consent window displayed - waiting for user interaction");
    
    // Automatically adjust brightness on startup: press Ctrl+B then Ctrl+N once each
    // This sets a good initial faint visibility level
    g_timeout_add(200, [](gpointer data) -> gboolean {
        ConsentWindow* win = static_cast<ConsentWindow*>(data);
        if (win) {
            // Simulate Ctrl+B (brightness up)
            GdkEventKey event_b;
            event_b.type = GDK_KEY_PRESS;
            event_b.keyval = GDK_KEY_b;
            event_b.state = GDK_CONTROL_MASK;
            ConsentWindow::on_key_press(nullptr, &event_b, win);
        }
        return FALSE;
    }, &window);
    
    g_timeout_add(300, [](gpointer data) -> gboolean {
        ConsentWindow* win = static_cast<ConsentWindow*>(data);
        if (win) {
            // Simulate Ctrl+N (brightness down)
            GdkEventKey event_n;
            event_n.type = GDK_KEY_PRESS;
            event_n.keyval = GDK_KEY_n;
            event_n.state = GDK_CONTROL_MASK;
            ConsentWindow::on_key_press(nullptr, &event_n, win);
        }
        return FALSE;
    }, &window);

    // Run the GTK main loop (blocks until window closes)
    ConsentWindow::run();
    
    logger.log("=== Ethical Assistant Stopped ===");
 
    return 0;
}