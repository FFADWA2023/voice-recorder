#include "app_config.h"
#include <fstream>
#include <nlohmann/json.hpp>
#include <iostream>

bool AppConfig::load_from_file(const std::string& path) {
    std::ifstream f(path);
    if (!f.is_open()) return false;

    try {
        nlohmann::json j;
        f >> j;
        for (auto it = j.begin(); it != j.end(); ++it) {
            if (it.value().is_string()) string_values_[it.key()] = it.value().get<std::string>();
            else if (it.value().is_number_integer()) int_values_[it.key()] = it.value().get<int>();
            else if (it.value().is_boolean()) bool_values_[it.key()] = it.value().get<bool>();
        }
    } catch (std::exception& e) {
        std::cerr << "Failed to parse config: " << e.what() << "\n";
        return false;
    }
    return true;
}

std::string AppConfig::get_string(const std::string& key, const std::string& def) const {
    auto it = string_values_.find(key);
    return it != string_values_.end() ? it->second : def;
}

int AppConfig::get_int(const std::string& key, int def) const {
    auto it = int_values_.find(key);
    return it != int_values_.end() ? it->second : def;
}

bool AppConfig::get_bool(const std::string& key, bool def) const {
    auto it = bool_values_.find(key);
    return it != bool_values_.end() ? it->second : def;
}
