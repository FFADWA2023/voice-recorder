#pragma once
// ocr_analyzer.h
// OCR text extraction using tesseract

#include <string>
#include <functional>
#include <memory>

using OCRCallback = std::function<void(const std::string& text, bool success)>;

class OCRAnalyzer {
public:
    OCRAnalyzer();
    ~OCRAnalyzer();

    // Extract text from PNG image using tesseract
    // Calls callback with extracted text and success status
    bool analyze_image(const std::string& image_path, OCRCallback cb = nullptr);

    // Extract text and save to output file
    bool analyze_and_save(const std::string& image_path, 
                          const std::string& output_file, 
                          OCRCallback cb = nullptr);

    // Check if tesseract is available
    static bool is_available();

    // Set language for OCR (default: "eng")
    void set_language(const std::string& lang);

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
