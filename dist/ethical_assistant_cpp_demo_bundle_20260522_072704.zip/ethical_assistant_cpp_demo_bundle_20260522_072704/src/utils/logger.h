#pragma once
#include <string>
#include <fstream>
#include <mutex>

class Logger {
public:
    Logger(const std::string& filename);
    ~Logger();

    void log(const std::string& message);

private:
    std::ofstream ofs_;
    std::mutex mtx_;
};
