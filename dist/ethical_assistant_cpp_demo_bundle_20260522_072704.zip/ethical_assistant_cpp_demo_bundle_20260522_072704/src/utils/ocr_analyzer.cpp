#include "ocr_analyzer.h"
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <thread>
#include <fstream>
#include <chrono>
#include <algorithm>
#include "logger.h"

struct OCRAnalyzer::Impl {
    OCRCallback callback;
    std::string language = "eng";
};

OCRAnalyzer::OCRAnalyzer() : impl_(std::make_unique<Impl>()) {}

OCRAnalyzer::~OCRAnalyzer() = default;

bool OCRAnalyzer::is_available() {
    int ret = system("which tesseract > /dev/null 2>&1");
    return ret == 0;
}

void OCRAnalyzer::set_language(const std::string& lang) {
    impl_->language = lang;
}

bool OCRAnalyzer::analyze_and_save(const std::string& image_path,
                                   const std::string& output_file,
                                   OCRCallback cb) {
    impl_->callback = cb;

    std::thread([this, image_path, output_file]() {
        // Pre-process image for better OCR quality
        // Convert to high contrast, sharpen, and denoise
        auto now = std::chrono::system_clock::now();
        auto timestamp = std::chrono::system_clock::to_time_t(now);
        std::string processed_image = "/tmp/ocr_processed_" + std::to_string(timestamp) + ".png";
        
        // Use ImageMagick to enhance image for OCR
        std::ostringstream preprocess_cmd;
        preprocess_cmd << "convert '" << image_path << "' "
            << "-colorspace gray "           // Convert to grayscale
            << "-contrast-stretch 0 "        // Auto-level contrast
            << "-sharpen 0x1 "               // Sharpen edges
            << "-modulate 100,150 "          // Boost saturation
            << "-normalize "                 // Normalize color levels
            << "'" << processed_image << "' 2>/dev/null";
        
        int preprocess_ret = system(preprocess_cmd.str().c_str());
        std::string image_to_ocr = preprocess_ret == 0 ? processed_image : image_path;
        
        std::cout << "[OCRAnalyzer] Image preprocessing: " << (preprocess_ret == 0 ? "✓ Success" : "⚠ Skipped") << "\n";
        
        // IMPROVED tesseract command - optimized for multi-column and complex layouts
        std::ostringstream cmd;
        cmd << "tesseract '" << image_to_ocr << "' '" << output_file 
            << "' -l " << impl_->language 
            << " --psm 6 "           // Assume a single uniform block of text (BETTER for multi-column)
            << " --oem 3 "           // Use both legacy + LSTM neural network (highest accuracy)
            << " -c preserve_interword_spaces=1 "   // Maintain original spacing
            << " -c tessedit_create_txt=1 "         // Force .txt output
            << " -c tesseract_create_hocr=0 "       // Skip HOCR (faster)
            << " -c classify_bln_numeric_mode=0 "   // Better number/symbol recognition
            << " -c tessedit_char_blacklist= "      // Don't blacklist any chars
            << " -c tosp_force_make_prop_words=0 "  // Better word detection
            << " -c textord_tabfind_vertical_text=1 " // Detect vertical text
            << " txt "               // Output format
            << " 2>&1";              // Capture stderr too for debugging

        std::cout << "[OCRAnalyzer] Running OCR with PSM 6 (multi-column optimized)\n";
        std::cout << "[OCRAnalyzer] Processing: " << image_to_ocr << "\n";
        
        int ret = system(cmd.str().c_str());
        
        if (ret != 0) {
            std::cerr << "[OCRAnalyzer] ❌ Tesseract failed with code: " << ret << std::endl;
            std::cerr << "[OCRAnalyzer] Check image quality or tesseract installation\n";
            if (impl_->callback) {
                impl_->callback("", false);
            }
            // Clean up preprocessed image
            if (preprocess_ret == 0) {
                system(("rm -f '" + processed_image + "' 2>/dev/null").c_str());
            }
            return;
        }

        // Read extracted text
        std::string txt_file = output_file + ".txt";
        std::ifstream file(txt_file);
        
        std::string text;
        if (file.is_open()) {
            text = std::string((std::istreambuf_iterator<char>(file)),
                              std::istreambuf_iterator<char>());
            file.close();
            
            // Log detailed stats
            std::cout << "[OCRAnalyzer] ✅ OCR COMPLETE\n";
            std::cout << "[OCRAnalyzer] File: " << txt_file << "\n";
            std::cout << "[OCRAnalyzer] Size: " << text.length() << " characters\n";
            std::cout << "[OCRAnalyzer] Lines: " << std::count(text.begin(), text.end(), '\n') << "\n";
            std::cout << "[OCRAnalyzer] Words (approx): " << std::count(text.begin(), text.end(), ' ') + 1 << "\n";
            
            if (text.empty()) {
                std::cerr << "[OCRAnalyzer] ⚠️  WARNING: File is empty - image may be blank/blurry\n";
            } else {
                std::cout << "[OCRAnalyzer] Preview (first 400 chars):\n";
                std::cout << "---START---\n";
                std::cout << text.substr(0, 400) << "\n";
                std::cout << "---END PREVIEW---\n";
            }
        } else {
            std::cerr << "[OCRAnalyzer] ❌ Failed to read: " << txt_file << std::endl;
        }

        // Clean up preprocessed image
        if (preprocess_ret == 0) {
            system(("rm -f '" + processed_image + "' 2>/dev/null").c_str());
        }

        if (impl_->callback) {
            impl_->callback(text, !text.empty());
        }
    }).detach();

    return true;
}

bool OCRAnalyzer::analyze_image(const std::string& image_path, OCRCallback cb) {
    impl_->callback = cb;

    std::thread([this, image_path]() {
        auto now = std::chrono::system_clock::now();
        auto timestamp = std::chrono::system_clock::to_time_t(now);
        std::string tmp_output = "/tmp/ocr_output_" + std::to_string(timestamp);
        
        // Same PSM 6 optimization for single image analysis
        std::ostringstream cmd;
        cmd << "tesseract '" << image_path << "' '" << tmp_output 
            << "' -l " << impl_->language 
            << " --psm 6 "           
            << " --oem 3 "           
            << " -c preserve_interword_spaces=1 "   
            << " -c tessedit_create_txt=1 "         
            << " -c tesseract_create_hocr=0 "       
            << " -c classify_bln_numeric_mode=0 "   
            << " -c tessedit_char_blacklist= "      
            << " txt "               
            << " 2>&1";

        int ret = system(cmd.str().c_str());
        
        if (ret != 0) {
            std::cerr << "[OCRAnalyzer] Tesseract failed with code: " << ret << std::endl;
            if (impl_->callback) {
                impl_->callback("", false);
            }
            return;
        }

        std::string output_file = tmp_output + ".txt";
        std::ifstream file(output_file);
        
        if (!file.is_open()) {
            std::cerr << "[OCRAnalyzer] Failed to read OCR output: " << output_file << std::endl;
            if (impl_->callback) {
                impl_->callback("", false);
            }
            return;
        }

        std::string text((std::istreambuf_iterator<char>(file)),
                         std::istreambuf_iterator<char>());
        file.close();

        std::string rm_cmd = "rm -f '" + output_file + "' 2>/dev/null";
        system(rm_cmd.c_str());

        std::cout << "[OCRAnalyzer] ✅ Text extraction successful from: " << image_path << std::endl;
        std::cout << "[OCRAnalyzer] Extracted " << text.length() << " characters" << std::endl;

        if (impl_->callback) {
            impl_->callback(text, !text.empty());
        }
    }).detach();

    return true;
}