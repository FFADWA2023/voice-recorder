#include "logger.h"
#include <iostream>
#include <chrono>
#include <ctime>

Logger::Logger(const std::string& filename) {
    ofs_.open(filename, std::ios::app);
    if (!ofs_.is_open()) {
        std::cerr << "Failed to open log file: " << filename << "\n";
    }
}

Logger::~Logger() {
    if (ofs_.is_open()) ofs_.close();
}

void Logger::log(const std::string& message) {
    std::lock_guard<std::mutex> lock(mtx_);
    auto now = std::chrono::system_clock::now();
    std::time_t t = std::chrono::system_clock::to_time_t(now);
    std::string ts = std::string(std::ctime(&t));
    ts.pop_back(); // remove newline

    std::string line = "[" + ts + "] " + message;
    std::cout << line << std::endl;
    if (ofs_.is_open()) ofs_ << line << std::endl;
}
