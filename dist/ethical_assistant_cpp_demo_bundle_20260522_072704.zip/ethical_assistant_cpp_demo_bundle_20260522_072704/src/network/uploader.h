#pragma once
#include <string>
#include <cstdint>

class Uploader {
public:
    Uploader(const std::string &server_url, const std::string &api_key);
    ~Uploader();

    // Returns true if enabled (non-empty URL)
    bool is_enabled() const { return !server_url_.empty(); }

    // Upload raw audio chunk (blocking). Returns true on HTTP 200/201.
    bool upload_audio_chunk(const uint8_t* data, size_t len, uint64_t timestamp_ms);

private:
    std::string server_url_;
    std::string api_key_;
};
