#include "screen_streamer.h"
#include "../utils/logger.h"
#include <iostream>
#include <sstream>
#include <chrono>
#include <cstring>
#include <set>
#include <queue>
#include <vector>
#include <mutex>
#include <cstdio>

// websocketpp (client/server)
#include <websocketpp/config/asio.hpp>
#include <websocketpp/server.hpp>

using websocket_server = websocketpp::server<websocketpp::config::asio>;

// For programmatic GTK/GDK capture
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk-pixbuf/gdk-pixbuf.h>
#include <gdk/gdkx.h>        // ADD THIS LINE - provides gdk_x11_window_lookup_for_display
#include <X11/Xlib.h>        // ADD THIS LINE - provides Window type
#include <unistd.h>

// Local logging helper (logger singleton not available here)
static void log_msg(const std::string &m) {
    std::cout << m << std::endl;
}

// Global WebSocket server instance and client set (for frame broadcast)
static websocket_server* g_ws_server = nullptr;
static std::set<websocketpp::connection_hdl, std::owner_less<websocketpp::connection_hdl>> g_clients;
static std::mutex g_clients_mtx;

// Thread-safe queue to pass captured JPEG buffers from GTK main thread to server thread
static std::mutex gdk_capture_mtx;
static std::condition_variable gdk_capture_cv;
static std::deque<std::vector<uint8_t>> gdk_capture_queue;

struct GdkCaptureRequest {
    unsigned long window_id;
};

// Idle callback run on the GTK main loop to capture the window and push a JPEG buffer
// NOTE: gdk_pixbuf_get_from_window() causes Cairo assertion failures in multi-threaded scenarios
// Use xwd + ImageMagick instead for safer capture
static gboolean do_gdk_capture(gpointer data) {
    GdkCaptureRequest* req = static_cast<GdkCaptureRequest*>(data);
    if (!req) return FALSE;
    
    // Just signal that we're done without actually capturing
    // The fallback external command path will handle it
    {
        std::lock_guard<std::mutex> lk(gdk_capture_mtx);
        gdk_capture_queue.push_back(std::vector<uint8_t>()); // Empty marker
    }
    gdk_capture_cv.notify_one();
    
    delete req;
    return FALSE; // run once
}

ScreenStreamer::ScreenStreamer(int port)
    : port_(port), streaming_(false), shutdown_(false), 
      capture_interval_ms_(100), callback_(nullptr), window_id_(0), command_handler_(nullptr) {
}

ScreenStreamer::~ScreenStreamer() {
    stop();
}

bool ScreenStreamer::start() {
    if (streaming_.load()) {
        if (callback_) callback_("Streaming already active", false);
        return false;
    }

    streaming_.store(true);
    shutdown_.store(false);

    // Start server thread
    server_thread_ = std::make_unique<std::thread>([this]() {
        server_loop();
    });

    if (callback_) callback_("Screen streamer started on port " + std::to_string(port_), true);
    return true;
}

void ScreenStreamer::stop() {
    if (!streaming_.load()) return;

    shutdown_.store(true);
    streaming_.store(false);

    if (server_thread_ && server_thread_->joinable()) {
        server_thread_->join();
    }

    if (callback_) callback_("Screen streamer stopped", true);
}

int ScreenStreamer::connected_clients() const {
    // TODO: Implement client count tracking
    return 0;
}

void ScreenStreamer::server_loop() {
    log_msg("=== ScreenStreamer::server_loop() STARTED ===");
    
    // Minimal websocketpp server to accept connections and stream frames
    websocket_server server;
    server.init_asio();
    server.set_reuse_addr(true);
    g_ws_server = &server;
    
    log_msg("WebSocket server initialized");

    server.set_open_handler([this](websocketpp::connection_hdl h) {
        std::lock_guard<std::mutex> lock(g_clients_mtx);
        g_clients.insert(h);
        log_msg("WebSocket client connected (" + std::to_string(g_clients.size()) + " total)");
        // Send a small greeting text to confirm text messages are received
        try {
            websocketpp::lib::error_code ec;
            std::string welcome = "TEXT: Connected to Ethical Assistant stream server. Binary frames will follow.";
            g_ws_server->send(h, welcome, websocketpp::frame::opcode::text, ec);
            if (ec) log_msg(std::string("Welcome send error: ") + ec.message());
        } catch (const std::exception& e) {
            log_msg(std::string("Welcome send exception: ") + e.what());
        }
    });

    server.set_close_handler([this](websocketpp::connection_hdl h) {
        std::lock_guard<std::mutex> lock(g_clients_mtx);
        g_clients.erase(h);
        log_msg("WebSocket client disconnected (" + std::to_string(g_clients.size()) + " total)");
    });

    server.set_message_handler([this](websocketpp::connection_hdl h, websocket_server::message_ptr msg) {
        std::string payload = msg->get_payload();
        log_msg("WebSocket message: " + payload);
        
        // If it's not binary (image), assume it's a command from Android
        if (msg->get_opcode() != websocketpp::frame::opcode::binary) {
            if (command_handler_) {
                command_handler_(payload);
            }
        }
    });

    try {
        log_msg("Attempting to listen on port " + std::to_string(port_));
        websocketpp::lib::error_code ec;
        server.listen(port_);
        if (ec) {
            log_msg("Listen failed: " + ec.message());
            return;
        }
        log_msg("Listen successful, starting accept");
        
        server.start_accept();
        log_msg(std::string("WebSocket server listening on port ") + std::to_string(port_));

        // Run server in a separate thread
        log_msg("Starting WebSocket server thread");
        std::thread server_thread([&server]() {
            log_msg("WebSocket server thread running");
            server.run();
            log_msg("WebSocket server thread finished");
        });

        // Main loop: capture and broadcast frames continuously
        log_msg("Starting capture and broadcast loop");
        int frame_count = 0;
        while (!shutdown_.load()) {
            capture_and_broadcast();
            frame_count++;
            if (frame_count % 50 == 0) {  // Log every 50 frames to avoid spam
                log_msg("Frames broadcast: " + std::to_string(frame_count));
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(capture_interval_ms_));
        }

        // Stop server and wait for thread
        log_msg("Stopping WebSocket server");
        server.stop();
        if (server_thread.joinable()) {
            server_thread.join();
        }
        log_msg("WebSocket server stopped");
    } catch (const std::exception& e) {
        log_msg(std::string("WebSocket server error: ") + e.what());
    }

    g_ws_server = nullptr;
    log_msg("=== ScreenStreamer::server_loop() FINISHED ===");
}

void ScreenStreamer::capture_and_broadcast() {
    // Capture screen using xwd to capture specific window, then convert to a
    // resized JPEG to reduce frame size (helps mobile decode & memory).
    // Using JPEG + low quality avoids large PNGs which sometimes fail on Android.
    std::string screenshot_path = "/tmp/stream_frame.jpg";
    std::string cmd;

    // Try programmatic GDK capture first (preferred, no external commands)
    // NOTE: Disabled due to Cairo assertion failure in multi-threaded scenarios
    // The external command path is more reliable
    bool gdk_captured = false;
    std::vector<uint8_t> jpeg_buffer;

    // Skip GDK capture - use external commands only (more stable)
    if (false && window_id_ > 0) {
        // Request the GTK main loop to perform the capture via idle handler.
        GdkCaptureRequest* req = new GdkCaptureRequest();
        req->window_id = window_id_;
        g_idle_add(do_gdk_capture, req);

        // Wait up to 200ms for the GTK main loop to produce a capture
        std::unique_lock<std::mutex> lk(gdk_capture_mtx);
        if (gdk_capture_cv.wait_for(lk, std::chrono::milliseconds(200), [](){ return !gdk_capture_queue.empty(); })) {
            jpeg_buffer = std::move(gdk_capture_queue.front());
            gdk_capture_queue.pop_front();
            gdk_captured = (jpeg_buffer.size() > 0);
        } else {
            log_msg("GDK capture timed out, falling back to external commands");
        }
    }

    int ret = 0;
    if (!gdk_captured) {
        // Use ImageMagick 'convert' to resize to a max width of 720px and set quality.
        // If window_id_ is provided, capture that window, otherwise fall back to full screen.
        if (window_id_ > 0) {
            // Capture specific window by ID and output a resized JPEG
            cmd = "xwd -id " + std::to_string(window_id_) +
                  " 2>/dev/null | convert xwd:- -resize 720x -quality 60 jpg:- > " + screenshot_path + " 2>/dev/null";
        } else {
            // Fallback: capture full screen then resize/encode to JPEG
            cmd = "gnome-screenshot -f /tmp/stream_tmp.png 2>/dev/null && convert /tmp/stream_tmp.png -resize 720x -quality 60 jpg:" + screenshot_path + " 2>/dev/null";
        }

        ret = system(cmd.c_str());

        if (ret != 0) {
            // Log failure and the command that failed for diagnostics
            log_msg(std::string("Capture command failed (rc=") + std::to_string(ret) + "):");
            log_msg(cmd);

            // Try fallback #1: ImageMagick 'import' if available
            std::string fallback1 = "import -window " + std::to_string(window_id_) + " -resize 720x -quality 60 " + screenshot_path + " 2>/dev/null";
            if (window_id_ > 0) {
                int r2 = system(fallback1.c_str());
                if (r2 == 0) {
                    log_msg("Capture fallback #1 succeeded (import)");
                    ret = r2;
                } else {
                    log_msg(std::string("Fallback #1 failed (rc=") + std::to_string(r2) + "):");
                    log_msg(fallback1);
                }
            }

            // Try fallback #2: full-screen gnome-screenshot then convert
            if (ret != 0) {
                std::string fallback2 = "gnome-screenshot -f /tmp/stream_tmp.png 2>/dev/null && convert /tmp/stream_tmp.png -resize 720x -quality 60 jpg:" + screenshot_path + " 2>/dev/null";
                int r3 = system(fallback2.c_str());
                if (r3 == 0) {
                    log_msg("Capture fallback #2 succeeded (gnome-screenshot+convert)");
                    ret = r3;
                } else {
                    log_msg(std::string("Fallback #2 failed (rc=") + std::to_string(r3) + "):");
                    log_msg(fallback2);
                }
            }

            if (ret != 0) {
                log_msg("All capture attempts failed; skipping this frame");
                return;
            }
        }
    }

    std::vector<uint8_t> frame_data;

    if (gdk_captured) {
        frame_data = std::move(jpeg_buffer);
    } else {
        // Read JPEG file
        long size = 0;  // MOVED DECLARATION HERE - outside nested block
        
        // Diagnostic: confirm file exists and log size
        {
            FILE* testf = fopen(screenshot_path.c_str(), "rb");
            if (!testf) {
                log_msg(std::string("Screenshot file not found: ") + screenshot_path);
                return;
            }
            fseek(testf, 0, SEEK_END);
            long fsize = ftell(testf);
            fclose(testf);
            log_msg(std::string("Screenshot file present: ") + screenshot_path + " (" + std::to_string(fsize) + " bytes)");
        }

        FILE* f = fopen(screenshot_path.c_str(), "rb");
        if (!f) return;

        fseek(f, 0, SEEK_END);
        size = ftell(f);
        fseek(f, 0, SEEK_SET);

        frame_data.resize(size);
        size_t read = fread(frame_data.data(), 1, size, f);
        fclose(f);

        if (read != (size_t)size || frame_data.empty()) {
            log_msg("Failed to read full screenshot file");
            return;
        }
    }

    // Diagnostic: log frame size and skip extremely large frames
    size_t frame_size = frame_data.size();
    log_msg(std::string("Captured frame bytes: ") + std::to_string(frame_size));

    const size_t MAX_FRAME_BYTES = 800 * 1024; // 800 KB
    if (frame_size == 0 || frame_size > MAX_FRAME_BYTES) {
        log_msg(std::string("Skipping frame due to size: ") + std::to_string(frame_size));
        return;
    }

    // Broadcast frame to all connected clients
    {
        std::lock_guard<std::mutex> lock(g_clients_mtx);
        if (g_clients.empty()) return;

        for (auto& client : g_clients) {
            try {
                websocketpp::lib::error_code ec;
                g_ws_server->send(client, frame_data.data(), frame_data.size(),
                                  websocketpp::frame::opcode::binary, ec);
                if (ec) {
                    log_msg("Send error: " + ec.message());
                }
            } catch (const std::exception& e) {
                log_msg(std::string("Broadcast error: ") + e.what());
            }
        }
    }
}