#include "uploader.h"
#include <curl/curl.h>
#include <iostream>
#include <vector>
#include <fstream>
#include <sys/stat.h>
#include <sstream>

Uploader::Uploader(const std::string &server_url, const std::string &api_key)
    : server_url_(server_url), api_key_(api_key) {
    curl_global_init(CURL_GLOBAL_DEFAULT);
}

Uploader::~Uploader() {
    curl_global_cleanup();
}

static size_t curl_null_write(void* ptr, size_t size, size_t nmemb, void* userdata) {
    // discard
    return size * nmemb;
}

bool Uploader::upload_audio_chunk(const uint8_t* data, size_t len, uint64_t timestamp_ms) {
    if (server_url_.empty()) return false;

    CURL *curl = curl_easy_init();
    if (!curl) return false;

    struct curl_slist *headers = nullptr;
    if (!api_key_.empty()) {
        std::string auth = "Authorization: Bearer " + api_key_;
        headers = curl_slist_append(headers, auth.c_str());
    }

    curl_easy_setopt(curl, CURLOPT_URL, server_url_.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_null_write);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);

    // Use multipart/form-data with libcurl mime API. Attach timestamp metadata and binary.
    curl_mime *mime = curl_mime_init(curl);
    curl_mimepart *part = nullptr;

    // metadata part: timestamp
    part = curl_mime_addpart(mime);
    curl_mime_name(part, "timestamp_ms");
    std::string ts = std::to_string(timestamp_ms);
    curl_mime_data(part, ts.c_str(), CURL_ZERO_TERMINATED);

    // file part
    part = curl_mime_addpart(mime);
    curl_mime_name(part, "file");
    curl_mime_filename(part, "audio_chunk.pcm");
    curl_mime_type(part, "application/octet-stream");
    curl_mime_data(part, reinterpret_cast<const char*>(data), len);

    curl_easy_setopt(curl, CURLOPT_MIMEPOST, mime);

    CURLcode res = curl_easy_perform(curl);
    long resp_code = 0;
    if (res == CURLE_OK) {
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &resp_code);
    } else {
        std::cerr << "curl perform error: " << curl_easy_strerror(res) << std::endl;
    }

    curl_mime_free(mime);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    return (res == CURLE_OK) && (resp_code >= 200 && resp_code < 300);
}
