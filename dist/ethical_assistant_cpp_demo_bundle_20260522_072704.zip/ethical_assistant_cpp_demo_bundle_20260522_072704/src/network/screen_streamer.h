#ifndef SCREEN_STREAMER_H
#define SCREEN_STREAMER_H

#include <string>
#include <memory>
#include <thread>
#include <atomic>
#include <mutex>
#include <vector>
#include <functional>

/**
 * ScreenStreamer: WebSocket server for streaming screen captures to Android/remote clients.
 * Captures screen frames periodically and broadcasts them as JPEG-encoded images over WebSocket.
 */
class ScreenStreamer {
public:
    using StreamCallback = std::function<void(const std::string&, bool)>;

    ScreenStreamer(int port = 8765);
    ~ScreenStreamer();

    // Start WebSocket server on specified port
    bool start();

    // Stop WebSocket server and close all connections
    void stop();

    // Check if streaming is active
    bool is_streaming() const { return streaming_.load(); }

    // Set frame capture interval (ms)
    void set_capture_interval(int ms) { capture_interval_ms_ = ms; }

    // Get number of connected clients
    int connected_clients() const;

    // Callback for logging/debugging
    void set_callback(StreamCallback cb) { callback_ = cb; }

    // Set GTK window ID to capture (instead of full screen)
    void set_window_id(unsigned long window_id) { window_id_ = window_id; }

    // Set command handler for receiving button clicks from Android
    using CommandHandler = std::function<void(const std::string& command)>;
    void set_command_handler(CommandHandler handler) { command_handler_ = handler; }

private:
    int port_;
    std::atomic<bool> streaming_;
    std::atomic<bool> shutdown_;
    int capture_interval_ms_;
    std::unique_ptr<std::thread> server_thread_;
    StreamCallback callback_;
    unsigned long window_id_;  // GTK window ID to capture
    CommandHandler command_handler_;

    void server_loop();
    void capture_and_broadcast();
};

#endif // SCREEN_STREAMER_H
