#pragma once
#include <string>
#include <functional>
#include <memory>

class WebSocketClient {
public:
    using MessageCallback = std::function<void(const std::string&)>;

    WebSocketClient();
    ~WebSocketClient();

    // Connect to ws:// or wss:// server
    bool connect(const std::string& url);

    // Send a text message
    bool send(const std::string& message);

    // Close connection
    void close();

    // Register callback for incoming messages
    void set_message_callback(MessageCallback cb);

    // Check connection status
    bool is_connected() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
