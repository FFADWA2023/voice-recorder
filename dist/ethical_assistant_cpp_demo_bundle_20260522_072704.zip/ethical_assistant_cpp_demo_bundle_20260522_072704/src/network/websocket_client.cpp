#include "websocket_client.h"
#include <iostream>
#include <thread>
#include <atomic>
#include <mutex>
#include <condition_variable>
#include <websocketpp/config/asio_no_tls_client.hpp>
#include <websocketpp/client.hpp>

using ws_client = websocketpp::client<websocketpp::config::asio_client>;

struct WebSocketClient::Impl {
    ws_client client;
    websocketpp::connection_hdl hdl;
    std::atomic<bool> connected{false};
    std::thread asio_thread;
    std::mutex mtx;
    std::condition_variable cv;
    WebSocketClient::MessageCallback message_cb;

    Impl() { client.init_asio(); }
};

WebSocketClient::WebSocketClient() : impl_(new Impl()) {}
WebSocketClient::~WebSocketClient() { close(); }

bool WebSocketClient::connect(const std::string& url) {
    try {
        // Fix: use a named std::error_code
        websocketpp::lib::error_code ec;  
        auto con = impl_->client.get_connection(url, ec);
        if (ec) {
            std::cerr << "WebSocket connection failed: " << ec.message() << std::endl;
            return false;
        }

        impl_->hdl = con->get_handle();

        // Handlers
        impl_->client.set_open_handler([this](websocketpp::connection_hdl){
            impl_->connected.store(true);
            if (impl_->message_cb) impl_->message_cb("Connected to server");
        });

        impl_->client.set_message_handler([this](websocketpp::connection_hdl, ws_client::message_ptr msg){
            if (impl_->message_cb) impl_->message_cb(msg->get_payload());
        });

        impl_->client.set_close_handler([this](websocketpp::connection_hdl){
            impl_->connected.store(false);
            if (impl_->message_cb) impl_->message_cb("Disconnected from server");
        });

        impl_->client.set_fail_handler([this](websocketpp::connection_hdl){
            impl_->connected.store(false);
            if (impl_->message_cb) impl_->message_cb("Connection failed");
        });

        // Connect and start ASIO loop
        impl_->client.connect(con);
        impl_->asio_thread = std::thread([this](){ impl_->client.run(); });

        return true;
    } catch (const std::exception& e) {
        std::cerr << "WebSocket connect exception: " << e.what() << "\n";
        return false;
    }
}


bool WebSocketClient::send(const std::string& message) {
    if (!impl_->connected.load()) return false;
    websocketpp::lib::error_code ec;
    impl_->client.send(impl_->hdl, message, websocketpp::frame::opcode::text, ec);
    return !ec;
}

void WebSocketClient::close() {
    if (impl_->connected.load()) {
        websocketpp::lib::error_code ec;
        impl_->client.close(impl_->hdl, websocketpp::close::status::normal, "", ec);
        if (impl_->asio_thread.joinable()) impl_->asio_thread.join();
    }
}

void WebSocketClient::set_message_callback(MessageCallback cb) {
    impl_->message_cb = cb;
}

bool WebSocketClient::is_connected() const { return impl_->connected.load(); }
