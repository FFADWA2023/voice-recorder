// filepath: /home/dell/ethical_assistant/src/ui/consent_window_demo.cpp
// DEMO MODE - voice recorder + Gemini chat (no screenshot/streaming)
#include "consent_window.h"
#include "../capture/audio_capture.h"
#include "../encode/audio_encoder.h"
#include "../network/uploader.h"
#include "../capture/screenshot_capture.h"
#include "../network/screen_streamer.h"
#include "../utils/ocr_analyzer.h"
#include "../ai/ai_service.h"
#include "../app_config.h"
#include "../utils/logger.h"
#include <gtk/gtk.h>
#include <string>
#include <atomic>
#include <thread>
#include <chrono>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <iostream>

static AudioCapture*     g_audio_capture = nullptr;
static AudioEncoder*     g_audio_encoder = nullptr;
static Uploader*         g_uploader      = nullptr;
static std::atomic<bool> g_is_recording(false);
static Logger*           g_logger        = nullptr;
static std::string       g_current_recording_path;

// ---- helpers ----
static void append_to_chat(GtkTextView* text_view, const std::string& sender, const std::string& message) {
    GtkTextBuffer* buffer = gtk_text_view_get_buffer(text_view);
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(buffer, &end);
    std::string formatted = sender + ":\n" + message + "\n\n";
    gtk_text_buffer_insert(buffer, &end, formatted.c_str(), -1);
    gtk_text_view_scroll_to_iter(text_view, &end, 0.0, FALSE, 0.0, 1.0);
}

static std::string get_input_text(GtkWidget* w) {
    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(w));
    GtkTextIter s, e;
    gtk_text_buffer_get_start_iter(buf, &s);
    gtk_text_buffer_get_end_iter(buf, &e);
    gchar* t = gtk_text_buffer_get_text(buf, &s, &e, FALSE);
    std::string r(t ? t : "");
    g_free(t);
    return r;
}

static void set_input_text(GtkWidget* w, const std::string& text) {
    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(w));
    gtk_text_buffer_set_text(buf, text.c_str(), -1);
}

static void query_gemini_and_display(ConsentWindow* self, const std::string& question);

// ---- GTK init/run ----
void ConsentWindow::init(int& argc, char**& argv) { gtk_init(&argc, &argv); }
void ConsentWindow::run() { gtk_main(); }

// ---- Constructor ----
ConsentWindow::ConsentWindow(AppConfig* config, Logger* logger)
    : window_(nullptr), vbox_(nullptr),
      indicator_label_(nullptr), start_button_(nullptr),
      stop_button_(nullptr), screenshot_button_(nullptr),
      screenshot_area_button_(nullptr), stream_button_(nullptr),
      stop_stream_button_(nullptr), status_label_(nullptr),
      chat_text_view_(nullptr), input_entry_(nullptr),
      ask_button_(nullptr), case1_button_(nullptr),
      case2_button_(nullptr), case3_button_(nullptr), case4_button_(nullptr),
      search_bar_(nullptr), search_entry_(nullptr), search_case_button_(nullptr),
      search_status_label_(nullptr), search_current_match_(0),
      config_(config), logger_(logger),
      screenshot_capture_(nullptr),
      ocr_analyzer_(nullptr),
      ai_service_(std::make_unique<AIService>(AIService::ServiceType::GEMINI)) {

    g_logger = logger_;

    window_ = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window_), "Ethical Assistant — Demo");
    gtk_window_set_default_size(GTK_WINDOW(window_), 320, 600);
    gtk_window_set_resizable(GTK_WINDOW(window_), TRUE);
    gtk_window_set_keep_above(GTK_WINDOW(window_), TRUE);

    vbox_ = gtk_box_new(GTK_ORIENTATION_VERTICAL, 6);
    gtk_container_set_border_width(GTK_CONTAINER(vbox_), 8);
    gtk_container_add(GTK_CONTAINER(window_), vbox_);

    // ---- indicator + start/stop row ----
    indicator_label_ = gtk_label_new(nullptr);
    gtk_label_set_markup(GTK_LABEL(indicator_label_),
        "<span font_desc='18'><span foreground='#888888'>●</span></span>\n"
        "<span font_desc='8'>Idle</span>");
    gtk_label_set_justify(GTK_LABEL(indicator_label_), GTK_JUSTIFY_CENTER);

    GtkWidget* ctrl_row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 4);
    gtk_box_pack_start(GTK_BOX(ctrl_row), indicator_label_, FALSE, FALSE, 0);
    start_button_ = gtk_button_new_with_label("Start");
    stop_button_  = gtk_button_new_with_label("Stop");
    gtk_widget_set_sensitive(stop_button_, FALSE);
    gtk_box_pack_start(GTK_BOX(ctrl_row), start_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(ctrl_row), stop_button_,  TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(vbox_), ctrl_row, FALSE, FALSE, 0);

    status_label_ = gtk_label_new("Ready — press Start to record");
    gtk_box_pack_start(GTK_BOX(vbox_), status_label_, FALSE, FALSE, 0);

    // ---- chat separator ----
    gtk_box_pack_start(GTK_BOX(vbox_), gtk_separator_new(GTK_ORIENTATION_HORIZONTAL), FALSE, FALSE, 2);

    // ---- chat display ----
    GtkWidget* scroll = gtk_scrolled_window_new(nullptr, nullptr);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_widget_set_size_request(scroll, -1, 180);
    gtk_widget_set_vexpand(scroll, TRUE);
    chat_text_view_ = gtk_text_view_new();
    gtk_text_view_set_editable(GTK_TEXT_VIEW(chat_text_view_), FALSE);
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(chat_text_view_), GTK_WRAP_WORD);
    gtk_container_add(GTK_CONTAINER(scroll), chat_text_view_);
    gtk_box_pack_start(GTK_BOX(vbox_), scroll, TRUE, TRUE, 0);

    // ---- input text view ----
    GtkWidget* input_scroll = gtk_scrolled_window_new(nullptr, nullptr);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(input_scroll), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_widget_set_size_request(input_scroll, -1, 100);
    gtk_widget_set_vexpand(input_scroll, TRUE);
    GtkWidget* input_tv = gtk_text_view_new();
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(input_tv), GTK_WRAP_WORD);
    gtk_text_view_set_left_margin(GTK_TEXT_VIEW(input_tv), 4);
    gtk_text_view_set_right_margin(GTK_TEXT_VIEW(input_tv), 4);
    input_entry_ = input_tv;
    gtk_container_add(GTK_CONTAINER(input_scroll), input_tv);
    gtk_box_pack_start(GTK_BOX(vbox_), input_scroll, TRUE, TRUE, 0);

    // ---- ask button ----
    ask_button_ = gtk_button_new_with_label("📤 Send");
    gtk_widget_set_hexpand(ask_button_, TRUE);
    gtk_box_pack_start(GTK_BOX(vbox_), ask_button_, FALSE, FALSE, 2);

    // ---- clear / paste / transcribe / save ----
    GtkWidget* util_row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 4);
    clear_button_ = gtk_button_new_with_label("🗑️");
    paste_button_ = gtk_button_new_with_label("📋");
    GtkWidget* transcribe_button = gtk_button_new_with_label("🎙");
    GtkWidget* save_chat_button  = gtk_button_new_with_label("💾");
    gtk_box_pack_start(GTK_BOX(util_row), clear_button_,      FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(util_row), paste_button_,      FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(util_row), transcribe_button,  FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(util_row), save_chat_button,   FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox_), util_row, FALSE, FALSE, 0);

    // ---- case buttons ----
    GtkWidget* case_row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 4);
    case1_button_ = gtk_button_new_with_label("Case 1");
    case2_button_ = gtk_button_new_with_label("Case 2");
    case3_button_ = gtk_button_new_with_label("Case 3");
    case4_button_ = gtk_button_new_with_label("Case 4");
    gtk_box_pack_start(GTK_BOX(case_row), case1_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(case_row), case2_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(case_row), case3_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(case_row), case4_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(vbox_), case_row, FALSE, FALSE, 0);

    // ---- signals ----
    g_signal_connect(window_,          "destroy",        G_CALLBACK(gtk_main_quit),                             nullptr);
    gtk_widget_set_can_focus(window_, TRUE);
    g_signal_connect(window_,          "key-press-event",G_CALLBACK(ConsentWindow::on_key_press),               this);
    g_signal_connect(start_button_,    "clicked",        G_CALLBACK(ConsentWindow::on_start_clicked),           this);
    g_signal_connect(stop_button_,     "clicked",        G_CALLBACK(ConsentWindow::on_stop_clicked),            this);
    g_signal_connect(ask_button_,      "clicked",        G_CALLBACK(ConsentWindow::on_ask_clicked),             this);
    g_signal_connect(clear_button_,    "clicked",        G_CALLBACK(ConsentWindow::on_clear_clicked),           this);
    g_signal_connect(paste_button_,    "clicked",        G_CALLBACK(ConsentWindow::on_paste_clicked),           this);
    g_signal_connect(transcribe_button,"clicked",        G_CALLBACK(ConsentWindow::on_transcribe_clicked),      this);
    g_signal_connect(save_chat_button, "clicked",        G_CALLBACK(ConsentWindow::on_save_chat_clicked),       this);
    g_signal_connect(case1_button_,    "clicked",        G_CALLBACK(ConsentWindow::on_case1_clicked),           this);
    g_signal_connect(case2_button_,    "clicked",        G_CALLBACK(ConsentWindow::on_case2_clicked),           this);
    g_signal_connect(case3_button_,    "clicked",        G_CALLBACK(ConsentWindow::on_case3_clicked),           this);
    g_signal_connect(case4_button_,    "clicked",        G_CALLBACK(ConsentWindow::on_case4_clicked),           this);

    // ---- audio init ----
    const char* upload_url = getenv("ETHICS_ASSISTANT_UPLOAD_URL");
    const char* api_key    = getenv("ETHICS_ASSISTANT_API_KEY");
    g_uploader      = new Uploader(std::string(upload_url ? upload_url : ""),
                                   std::string(api_key    ? api_key    : ""));
    g_audio_capture = new AudioCapture();
    g_audio_encoder = new AudioEncoder();

    history_file_path_ = "/home/dell/recordings/conversation_history.json";
    load_conversation_history(history_file_path_);

    if (g_logger) g_logger->log("DEMO MODE: recorder + chat UI started");
}

// ---- Destructor ----
ConsentWindow::~ConsentWindow() {
    if (g_is_recording.load() && g_audio_capture) { g_audio_capture->stop(); g_is_recording = false; }
    if (g_audio_encoder) { g_audio_encoder->finalize(); delete g_audio_encoder; g_audio_encoder = nullptr; }
    if (g_audio_capture) { delete g_audio_capture; g_audio_capture = nullptr; }
    if (g_uploader)      { delete g_uploader;      g_uploader      = nullptr; }
}

void ConsentWindow::show() { if (window_) gtk_widget_show_all(window_); }
void ConsentWindow::hide() { if (window_) gtk_widget_hide(window_); }

// ---- set_recording_state ----
void ConsentWindow::set_recording_state(bool recording) {
    if (recording) {
        gtk_label_set_markup(GTK_LABEL(indicator_label_),
            "<span font_desc='18'><span foreground='#d9534f'>●</span></span>\n"
            "<span font_desc='8' foreground='#d9534f'>Recording</span>");
        gtk_widget_set_sensitive(start_button_, FALSE);
        gtk_widget_set_sensitive(stop_button_,  TRUE);
        gtk_label_set_text(GTK_LABEL(status_label_), "Recording...");
    } else {
        gtk_label_set_markup(GTK_LABEL(indicator_label_),
            "<span font_desc='18'><span foreground='#888888'>●</span></span>\n"
            "<span font_desc='8'>Idle</span>");
        gtk_widget_set_sensitive(start_button_, TRUE);
        gtk_widget_set_sensitive(stop_button_,  FALSE);
        gtk_label_set_text(GTK_LABEL(status_label_), "Ready");
    }
}

// ---- Start / Stop ----
void ConsentWindow::on_start_clicked(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self || g_is_recording.load()) return;

    std::string output_dir = "/home/dell/recordings";
    int sample_rate = 16000, channels = 1;
    if (self->config_) {
        output_dir  = self->config_->get_string("output_dir", output_dir);
        sample_rate = self->config_->get_int("sample_rate", sample_rate);
        channels    = self->config_->get_int("channels", channels);
    }
    // Ensure output directory exists
    try { std::filesystem::create_directories(output_dir); } catch (...) {}
    auto now = std::chrono::system_clock::now();
    std::time_t t = std::chrono::system_clock::to_time_t(now);
    char fname[256];
    std::strftime(fname, sizeof(fname), "recording_%Y%m%d_%H%M%S.wav", std::localtime(&t));
    std::string output_file = output_dir + "/" + fname;

    if (!g_audio_encoder->init(output_file, sample_rate, channels)) {
        gtk_label_set_text(GTK_LABEL(self->status_label_), "Failed to init encoder");
        return;
    }
    auto cb = [](const uint8_t* data, size_t len, uint64_t) {
        if (g_audio_encoder) g_audio_encoder->encode(data, len);
    };
    if (!g_audio_capture || !g_audio_capture->start(cb)) {
        gtk_label_set_text(GTK_LABEL(self->status_label_), "Failed to start capture");
        return;
    }
    g_current_recording_path = output_file;
    g_is_recording = true;
    self->set_recording_state(true);
    if (g_logger) g_logger->log("Recording started: " + output_file);
}

void ConsentWindow::on_stop_clicked(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self || !g_is_recording.load()) return;

    if (g_audio_capture) g_audio_capture->stop();
    if (g_audio_encoder) g_audio_encoder->finalize();

    // Set last_recording_path_ directly from what was just recorded
    if (!g_current_recording_path.empty())
        self->last_recording_path_ = g_current_recording_path;

    g_is_recording = false;
    self->set_recording_state(false);
    append_to_chat(GTK_TEXT_VIEW(self->chat_text_view_), "System", "Recording saved.");
    if (g_logger) g_logger->log("Recording stopped");
}

// ---- Gemini query helper ----
static void query_gemini_and_display(ConsentWindow* self, const std::string& question) {
    if (!self || !self->get_ai_service()) {
        append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", "AI service not available.");
        return;
    }
    self->add_to_conversation_history("user", question);

    std::thread([self, question]() {
        std::string answer;
        self->get_ai_service()->ask_question(question,
            [&answer](const std::string& response, bool /*success*/) {
                answer = response;
            });
        if (answer.empty()) answer = "(no response)";
        auto* p = new std::pair<ConsentWindow*, std::string>(self, answer);
        gdk_threads_add_idle([](gpointer d) -> gboolean {
            auto* pp = static_cast<std::pair<ConsentWindow*, std::string>*>(d);
            append_to_chat(GTK_TEXT_VIEW(pp->first->get_chat_text_view()), "AI", pp->second);
            pp->first->add_to_conversation_history("assistant", pp->second);
            delete pp;
            return FALSE;
        }, p);
    }).detach();
}

// ---- Ask ----
void ConsentWindow::on_ask_clicked(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    std::string q = get_input_text(self->input_entry_);
    if (q.empty()) return;
    append_to_chat(GTK_TEXT_VIEW(self->chat_text_view_), "You", q);
    set_input_text(self->input_entry_, "");
    query_gemini_and_display(self, q);
}

// ---- Clear ----
void ConsentWindow::on_clear_clicked(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(self->chat_text_view_));
    gtk_text_buffer_set_text(buf, "", -1);
    set_input_text(self->input_entry_, "");
}

// ---- Paste (copy chat to clipboard) ----
void ConsentWindow::on_paste_clicked(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(self->chat_text_view_));
    GtkTextIter s, e;
    gtk_text_buffer_get_start_iter(buf, &s);
    gtk_text_buffer_get_end_iter(buf, &e);
    gchar* text = gtk_text_buffer_get_text(buf, &s, &e, FALSE);
    if (text && strlen(text) > 0) {
        GtkClipboard* cb = gtk_clipboard_get(GDK_SELECTION_CLIPBOARD);
        gtk_clipboard_set_text(cb, text, -1);
        append_to_chat(GTK_TEXT_VIEW(self->chat_text_view_), "System", "Chat copied to clipboard.");
    }
    g_free(text);
}

// ---- Transcribe ----
void ConsentWindow::on_transcribe_clicked(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self || !self->input_entry_) return;
    if (self->last_recording_path_.empty()) {
        append_to_chat(GTK_TEXT_VIEW(self->chat_text_view_), "System",
            "No recording to transcribe yet. Record something first, then press Stop.");
        return;
    }
    if (!std::filesystem::exists(self->last_recording_path_)) {
        append_to_chat(GTK_TEXT_VIEW(self->chat_text_view_), "System",
            "Recording file not found: " + self->last_recording_path_);
        return;
    }
    std::string cmd = "/home/dell/ethical_assistant/transcribe.sh \"" + self->last_recording_path_ + "\"";
    if (g_logger) g_logger->log("Transcribing: " + self->last_recording_path_);
    std::thread([self, cmd]() {
        FILE* fp = popen(cmd.c_str(), "r");
        if (!fp) {
            gdk_threads_add_idle([](gpointer d) -> gboolean {
                auto* s = static_cast<ConsentWindow*>(d);
                append_to_chat(GTK_TEXT_VIEW(s->chat_text_view_), "System", "Transcription failed to launch.");
                return FALSE;
            }, self);
            return;
        }
        std::string result;
        char buf[256];
        while (fgets(buf, sizeof(buf), fp)) result += buf;
        pclose(fp);
        if (!result.empty() && result.back() == '\n') result.pop_back();
        auto* p = new std::pair<ConsentWindow*, std::string>(self, result);
        gdk_threads_add_idle([](gpointer d) -> gboolean {
            auto* pp = static_cast<std::pair<ConsentWindow*, std::string>*>(d);
            set_input_text(pp->first->input_entry_, pp->second);
            delete pp;
            return FALSE;
        }, p);
    }).detach();
}

// ---- Save chat ----
void ConsentWindow::on_save_chat_clicked(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(self->chat_text_view_));
    GtkTextIter s, e;
    gtk_text_buffer_get_start_iter(buf, &s);
    gtk_text_buffer_get_end_iter(buf, &e);
    gchar* text = gtk_text_buffer_get_text(buf, &s, &e, FALSE);
    if (!text) return;
    std::time_t t = std::time(nullptr);
    char fname[512];
    std::string outdir = self->config_ ? self->config_->get_string("output_dir", "/tmp") : std::string("/tmp");
    snprintf(fname, sizeof(fname), "%s/gemini_chat_%lld.txt", outdir.c_str(), (long long)t);
    std::ofstream of(fname);
    if (of.is_open()) { of << text; of.close(); }
    g_free(text);
    append_to_chat(GTK_TEXT_VIEW(self->chat_text_view_), "System", std::string("Saved chat to: ") + fname);
}

// ---- Case buttons ----
void ConsentWindow::on_case1_clicked(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    std::string t = get_input_text(self->input_entry_);
    if (t.empty()) return;
    std::string instr =
        "\n\n[INSTRUCTION]: You are the candidate. Detect the input language (French or English) and reply in the same language. "
        "Use the input as context and IMPROVISE realistic experience details that fit the candidate's profile and field. "
        "Do not quote or repeat the input. Do not add headings or bullets. Output only the response.";
    set_input_text(self->input_entry_, t + instr);
    ConsentWindow::on_ask_clicked(nullptr, user_data);
}

void ConsentWindow::on_case2_clicked(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    std::string t = get_input_text(self->input_entry_);
    if (t.empty()) return;
    std::string instr = "\n\n[INSTRUCTION]: YOU MUST RESPOND WITH ONLY THE EXACT PROGRAM OUTPUT (stdout/stderr). "
                        "ZERO explanations, commentary, or code. NOTHING BUT THE OUTPUT.";
    set_input_text(self->input_entry_, t + instr);
    ConsentWindow::on_ask_clicked(nullptr, user_data);
}

void ConsentWindow::on_case3_clicked(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    std::string t = get_input_text(self->input_entry_);
    if (t.empty()) return;
    std::string instr = "\n\n[INSTRUCTION]: RESPOND WITH ONLY THE SINGLE BEST OPTION/CHOICE NAME. "
                        "NO reasoning, no explanation, no extra words.";
    set_input_text(self->input_entry_, t + instr);
    ConsentWindow::on_ask_clicked(nullptr, user_data);
}

void ConsentWindow::on_case4_clicked(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    std::string t = get_input_text(self->input_entry_);
    if (t.empty()) return;
    std::string instr = "\n\n[INSTRUCTION]: RESPOND WITH ONLY THE COMPLETE WORKING CODE/FUNCTION. "
                        "ZERO explanations, no markdown, no code block markers. RAW CODE ONLY.";
    set_input_text(self->input_entry_, t + instr);
    ConsentWindow::on_ask_clicked(nullptr, user_data);
}

// ---- Key press shortcuts ----
gboolean ConsentWindow::on_key_press(GtkWidget*, GdkEventKey* event, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return FALSE;
    if (!(event->state & GDK_CONTROL_MASK)) return FALSE;
    switch (event->keyval) {
        case GDK_KEY_r: case GDK_KEY_R:
            ConsentWindow::on_start_clicked(nullptr, self); return TRUE;
        case GDK_KEY_o: case GDK_KEY_O:
            ConsentWindow::on_stop_clicked(nullptr, self);  return TRUE;
        case GDK_KEY_d: case GDK_KEY_D:
            ConsentWindow::on_ask_clicked(nullptr, self);   return TRUE;
        case GDK_KEY_l: case GDK_KEY_L:
            ConsentWindow::on_clear_clicked(nullptr, self); return TRUE;
        case GDK_KEY_c: case GDK_KEY_C:
            ConsentWindow::on_paste_clicked(nullptr, self); return TRUE;
        case GDK_KEY_x: case GDK_KEY_X:
            ConsentWindow::on_transcribe_clicked(nullptr, self); return TRUE;
        case GDK_KEY_y: case GDK_KEY_Y:
            ConsentWindow::on_save_chat_clicked(nullptr, self); return TRUE;
        case GDK_KEY_1: ConsentWindow::on_case1_clicked(nullptr, self); return TRUE;
        case GDK_KEY_2: ConsentWindow::on_case2_clicked(nullptr, self); return TRUE;
        case GDK_KEY_3: ConsentWindow::on_case3_clicked(nullptr, self); return TRUE;
        case GDK_KEY_4: ConsentWindow::on_case4_clicked(nullptr, self); return TRUE;
        case GDK_KEY_e: case GDK_KEY_E:
            gtk_widget_grab_focus(self->input_entry_); return TRUE;
        case GDK_KEY_f: case GDK_KEY_F:
            self->show_search_bar(); return TRUE;
        default: return FALSE;
    }
}

// ---- Conversation history ----
void ConsentWindow::add_to_conversation_history(const std::string& role, const std::string& content) {
    conversation_history_.push_back({role, content});
    save_conversation_history(history_file_path_);
}

void ConsentWindow::save_conversation_history(const std::string& filepath) {
    std::string path = filepath.empty() ? history_file_path_ : filepath;
    try {
        json arr = json::array();
        for (const auto& m : conversation_history_) arr.push_back({{"role", m.role}, {"content", m.content}});
        json obj; obj["messages"] = arr;
        obj["timestamp"] = std::chrono::system_clock::now().time_since_epoch().count();
        std::ofstream ofs(path); ofs << obj.dump(2);
    } catch (...) {}
}

void ConsentWindow::load_conversation_history(const std::string& filepath) {
    std::string path = filepath.empty() ? history_file_path_ : filepath;
    try {
        std::ifstream ifs(path);
        if (!ifs.good()) return;
        json obj; ifs >> obj;
        conversation_history_.clear();
        if (obj.contains("messages") && obj["messages"].is_array()) {
            for (const auto& m : obj["messages"])
                conversation_history_.push_back({m.value("role",""), m.value("content","")});
        }
    } catch (...) {}
}

void ConsentWindow::clear_conversation_history() { conversation_history_.clear(); }

// ---- Search ----
void ConsentWindow::show_search_bar() {
    if (!search_bar_) {
        search_bar_ = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 4);
        search_entry_ = gtk_entry_new();
        gtk_entry_set_placeholder_text(GTK_ENTRY(search_entry_), "Search...");
        search_case_button_ = gtk_toggle_button_new_with_label("Aa");
        GtkWidget* search_btn = gtk_button_new_with_label("🔍");
        GtkWidget* close_btn  = gtk_button_new_with_label("✕");
        search_status_label_  = gtk_label_new("");
        gtk_box_pack_start(GTK_BOX(search_bar_), search_entry_,       TRUE,  TRUE,  0);
        gtk_box_pack_start(GTK_BOX(search_bar_), search_case_button_, FALSE, FALSE, 0);
        gtk_box_pack_start(GTK_BOX(search_bar_), search_btn,          FALSE, FALSE, 0);
        gtk_box_pack_start(GTK_BOX(search_bar_), search_status_label_,FALSE, FALSE, 0);
        gtk_box_pack_start(GTK_BOX(search_bar_), close_btn,           FALSE, FALSE, 0);
        g_signal_connect(search_btn,          "clicked", G_CALLBACK(ConsentWindow::on_search_button_clicked), this);
        g_signal_connect(search_case_button_, "toggled", G_CALLBACK(ConsentWindow::on_search_case_toggled),   this);
        g_signal_connect(close_btn,           "clicked", G_CALLBACK(ConsentWindow::on_search_close),          this);
        gtk_box_pack_start(GTK_BOX(vbox_), search_bar_, FALSE, FALSE, 0);
        gtk_widget_show_all(search_bar_);
    }
    gtk_widget_show_all(search_bar_);
    gtk_widget_grab_focus(search_entry_);
}

void ConsentWindow::hide_search_bar() {
    if (search_bar_) gtk_widget_hide(search_bar_);
}

void ConsentWindow::perform_search(const std::string& query, bool case_sensitive) {
    if (query.empty()) return;
    search_matches_.clear();
    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(chat_text_view_));
    GtkTextIter start, end;
    gtk_text_buffer_get_bounds(buf, &start, &end);
    GtkTextTagTable* tt = gtk_text_buffer_get_tag_table(buf);
    if (!gtk_text_tag_table_lookup(tt, "search_highlight"))
        gtk_text_buffer_create_tag(buf, "search_highlight", "background", "#ffff00", nullptr);
    gtk_text_buffer_remove_tag_by_name(buf, "search_highlight", &start, &end);
    gchar* raw = gtk_text_buffer_get_text(buf, &start, &end, FALSE);
    std::string text(raw ? raw : ""); g_free(raw);
    std::string haystack = text, needle = query;
    if (!case_sensitive) {
        for (auto& c : haystack) c = tolower(c);
        for (auto& c : needle)   c = tolower(c);
    }
    size_t pos = 0;
    while ((pos = haystack.find(needle, pos)) != std::string::npos) {
        search_matches_.push_back((int)pos);
        GtkTextIter ms, me;
        gtk_text_buffer_get_iter_at_offset(buf, &ms, (int)pos);
        gtk_text_buffer_get_iter_at_offset(buf, &me, (int)(pos + needle.size()));
        gtk_text_buffer_apply_tag_by_name(buf, "search_highlight", &ms, &me);
        pos += needle.size();
    }
    char status[64];
    snprintf(status, sizeof(status), "%d match(es)", (int)search_matches_.size());
    if (search_status_label_) gtk_label_set_text(GTK_LABEL(search_status_label_), status);
    if (!search_matches_.empty()) {
        GtkTextIter it;
        gtk_text_buffer_get_iter_at_offset(buf, &it, search_matches_[0]);
        gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(chat_text_view_), &it, 0.0, FALSE, 0.0, 0.5);
    }
}

void ConsentWindow::on_search_button_clicked(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self || !self->search_entry_) return;
    const gchar* q = gtk_entry_get_text(GTK_ENTRY(self->search_entry_));
    bool cs = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(self->search_case_button_));
    self->perform_search(q ? q : "", cs);
}

void ConsentWindow::on_search_case_toggled(GtkToggleButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (!self || !self->search_entry_) return;
    const gchar* q = gtk_entry_get_text(GTK_ENTRY(self->search_entry_));
    if (q && strlen(q) > 0) {
        bool cs = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(self->search_case_button_));
        self->perform_search(q, cs);
    }
}

void ConsentWindow::on_search_close(GtkButton*, gpointer user_data) {
    auto* self = static_cast<ConsentWindow*>(user_data);
    if (self) self->hide_search_bar();
}

// ---- Window location stubs (not needed in demo) ----
void ConsentWindow::center_and_show_window() { if (window_) { gtk_widget_show_all(window_); gtk_window_present(GTK_WINDOW(window_)); } }
void ConsentWindow::move_cursor_if_outside() {}
void ConsentWindow::center_cursor_in_window() {}
