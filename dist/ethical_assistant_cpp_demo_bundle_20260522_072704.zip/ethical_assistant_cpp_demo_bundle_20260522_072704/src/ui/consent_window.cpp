// consent_window.cpp
// GTK3 small floating consent window implementation with screenshot/OCR
// Place this in src/ui/ and build with the provided CMake settings.

#include "consent_window.h"
#include "../capture/audio_capture.h"
#include "../capture/screenshot_capture.h"
#include "../encode/audio_encoder.h"
#include "../network/uploader.h"
#include "../network/screen_streamer.h"
#include "../ai/ai_service.h"
#include "../app_config.h"
#include "../utils/logger.h"
#include "../utils/ocr_analyzer.h"
#include <iostream>
#include <atomic>
#include <string>
#include <sstream>
#include <chrono>
#include <ctime>
#include <thread>
#include <filesystem>
#include <fstream>
#include <gtk/gtk.h>
#include <gdk/gdkx.h>
#include <nlohmann/json.hpp>
#include <X11/XKBlib.h>
#include <X11/Xlib.h>
#include <X11/keysym.h>
#include <X11/Xlib.h>

using json = nlohmann::json;

// Forward declaration of helper function
static void append_to_chat(GtkTextView* text_view, const std::string& sender, const std::string& message);

// Helper function to get text from input text view
static std::string get_input_text(GtkWidget* input_widget) {
    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(input_widget));
    GtkTextIter start, end;
    gtk_text_buffer_get_start_iter(buf, &start);
    gtk_text_buffer_get_end_iter(buf, &end);
    gchar* text = gtk_text_buffer_get_text(buf, &start, &end, FALSE);
    if (!text) return "";
    std::string result(text);
    g_free(text);
    return result;
}

// Helper function to set text to input text view
static void set_input_text(GtkWidget* input_widget, const std::string& text) {
    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(input_widget));
    gtk_text_buffer_set_text(buf, text.c_str(), -1);
}

// Static callback for Hide UI button
static void on_hide_button_clicked(GtkWidget* widget, gpointer data) {
    (void)widget;
    GtkWidget* win = GTK_WIDGET(data);
    gtk_widget_hide(win);
}


// Static callback for Close button
static void on_close_button_clicked(GtkWidget* widget, gpointer data) {
    (void)widget;
    (void)data;
    gtk_main_quit();
}

// Static callback for Brightness slider
static void on_brightness_changed(GtkRange* range, gpointer data) {
    GtkWidget* win = GTK_WIDGET(data);
    double value = gtk_range_get_value(range);
    // Slider range is 0-100, convert to 0.0-1.0 opacity
    gtk_widget_set_opacity(win, value / 100.0);
}

// Globals used by this UI to coordinate with capture/uploader singletons
static AudioCapture* g_audio_capture = nullptr;
static AudioEncoder* g_audio_encoder = nullptr;
static Uploader* g_uploader = nullptr;
static std::atomic<bool> g_is_recording(false);
static Logger* g_logger = nullptr;

static bool is_demo_mode() {
    const char* v = std::getenv("ETHICAL_DEMO_MODE");
    if (!v) return false;
    std::string m(v);
    for (auto& c : m) c = static_cast<char>(::tolower(c));
    return (m == "1" || m == "true" || m == "yes" || m == "on");
}

// ---- ConsentWindow static init/run ----
void ConsentWindow::init(int &argc, char** &argv) {
    gtk_init(&argc, &argv);
}

void ConsentWindow::run() {
    gtk_main();
}

// Add this helper function to your consent_window.cpp file


static void suppress_all_system_bells() {
    // Method 1: X11 system bell (most reliable)
    Display* display = GDK_DISPLAY_XDISPLAY(gdk_display_get_default());
    if (display) {
        XkbChangeEnabledControls(display, XkbUseCoreKbd, XkbAudibleBellMask, 0);
        XFlush(display);
    }
    
    // Method 2: xset command (immediate effect)
    system("xset b off 2>/dev/null");
    system("xset b 0 0 0 2>/dev/null");  // pitch, duration, volume all to 0
    
    // Method 3: Disable terminal bell
    system("setterm -blength 0 2>/dev/null");
    
    // Method 4: GTK settings (disable all feedback sounds)
    GtkSettings* settings = gtk_settings_get_default();
    if (settings) {
        g_object_set(settings,
            "gtk-error-bell", FALSE,
            "gtk-enable-input-feedback-sounds", FALSE,
            "gtk-enable-event-sounds", FALSE,
            NULL);
    }
    
    // Method 5: GNOME/MATE/Cinnamon sound settings (background, no wait)
    system("gsettings set org.gnome.desktop.wm.preferences audible-bell false 2>/dev/null &");
    system("gsettings set org.gnome.desktop.sound event-sounds false 2>/dev/null &");
    system("gsettings set org.cinnamon.desktop.wm.preferences audible-bell false 2>/dev/null &");
    system("gsettings set org.mate.sound event-sounds false 2>/dev/null &");
    
    // Method 6: PulseAudio bell module (unload if loaded)
    system("pactl unload-module module-x11-bell 2>/dev/null &");
    
    if (g_logger) {
        g_logger->log("✓ All system bells/buzzers suppressed (6 methods applied)");
    }
}

// ---- Constructor / Destructor ----
ConsentWindow::ConsentWindow(AppConfig* config, Logger* logger)
    : window_(nullptr), vbox_(nullptr),
      indicator_label_(nullptr), start_button_(nullptr),
      stop_button_(nullptr), screenshot_button_(nullptr),
      screenshot_area_button_(nullptr), stream_button_(nullptr),
      stop_stream_button_(nullptr), status_label_(nullptr),
      chat_text_view_(nullptr), input_entry_(nullptr),
      ask_button_(nullptr), case1_button_(nullptr),
      case2_button_(nullptr), case3_button_(nullptr), case4_button_(nullptr),
      search_bar_(nullptr), search_entry_(nullptr), search_case_button_(nullptr),
      search_status_label_(nullptr), search_current_match_(0),
      config_(config), logger_(logger),
      screenshot_capture_(std::make_unique<ScreenshotCapture>()),
      ocr_analyzer_(std::make_unique<OCRAnalyzer>()),
      ai_service_(std::make_unique<AIService>(AIService::ServiceType::GEMINI)) {

    g_logger = logger_;

    if (is_demo_mode()) {
        window_ = gtk_window_new(GTK_WINDOW_TOPLEVEL);
        gtk_window_set_title(GTK_WINDOW(window_), "Recorder (Demo Voice Only)");
        gtk_window_set_default_size(GTK_WINDOW(window_), 260, 180);
        gtk_window_set_resizable(GTK_WINDOW(window_), TRUE);
        gtk_window_set_decorated(GTK_WINDOW(window_), TRUE);
        gtk_window_set_keep_above(GTK_WINDOW(window_), TRUE);

        vbox_ = gtk_box_new(GTK_ORIENTATION_VERTICAL, 8);
        gtk_container_set_border_width(GTK_CONTAINER(vbox_), 10);
        gtk_container_add(GTK_CONTAINER(window_), vbox_);

        indicator_label_ = gtk_label_new(nullptr);
        gtk_label_set_markup(GTK_LABEL(indicator_label_),
            "<span font_desc='20'><span foreground='#888888'>●</span></span>\n<span font_desc='10'>Idle</span>");
        gtk_box_pack_start(GTK_BOX(vbox_), indicator_label_, FALSE, FALSE, 0);

        GtkWidget* row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 6);
        start_button_ = gtk_button_new_with_label("Start");
        stop_button_  = gtk_button_new_with_label("Stop");
        gtk_widget_set_sensitive(stop_button_, FALSE);
        gtk_box_pack_start(GTK_BOX(row), start_button_, TRUE, TRUE, 0);
        gtk_box_pack_start(GTK_BOX(row), stop_button_, TRUE, TRUE, 0);
        gtk_box_pack_start(GTK_BOX(vbox_), row, FALSE, FALSE, 0);

        status_label_ = gtk_label_new("Demo mode: voice recorder only");
        gtk_box_pack_start(GTK_BOX(vbox_), status_label_, FALSE, FALSE, 0);

        g_signal_connect(window_, "destroy", G_CALLBACK(gtk_main_quit), nullptr);
        gtk_widget_set_can_focus(window_, TRUE);
        g_signal_connect(window_, "key-press-event", G_CALLBACK(ConsentWindow::on_key_press), this);
        g_signal_connect(start_button_, "clicked", G_CALLBACK(ConsentWindow::on_start_clicked), this);
        g_signal_connect(stop_button_, "clicked", G_CALLBACK(ConsentWindow::on_stop_clicked), this);

        const char* upload_url = getenv("ETHICS_ASSISTANT_UPLOAD_URL");
        const char* api_key = getenv("ETHICS_ASSISTANT_API_KEY");
        if(!upload_url) upload_url = "";
        g_uploader = new Uploader(std::string(upload_url), std::string(api_key ? api_key : ""));
        g_audio_capture = new AudioCapture();
        g_audio_encoder = new AudioEncoder();

        suppress_all_system_bells();
        if (g_logger) g_logger->log("DEMO MODE ENABLED: voice-only UI");
        return;
    }
    
    // Create top-level window (floating, resizable by user with double-arrow cursor)
    window_ = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window_), "Recorder");
    gtk_window_set_default_size(GTK_WINDOW(window_), 240, 320);
    gtk_window_set_resizable(GTK_WINDOW(window_), TRUE); // Allow user to resize with edge drag (double-arrow)
    gtk_window_set_decorated(GTK_WINDOW(window_), TRUE);  // Show title bar for moving window

    // Set window opacity to 0 (fully transparent) by default; user can raise brightness to make it visible
    gtk_widget_set_opacity(GTK_WIDGET(window_), 0.0);

    // Always on top
    gtk_window_set_keep_above(GTK_WINDOW(window_), TRUE);

    // Hide from Activities/Taskbar
    gtk_window_set_skip_taskbar_hint(GTK_WINDOW(window_), TRUE);
    gtk_window_set_skip_pager_hint(GTK_WINDOW(window_), TRUE);

    // Set small margin and a vertical box
    vbox_ = gtk_box_new(GTK_ORIENTATION_VERTICAL, 8);
    gtk_container_set_border_width(GTK_CONTAINER(vbox_), 8);
    gtk_container_add(GTK_CONTAINER(window_), vbox_);

    // Window control buttons: Hide, Minimize, Close, Locate
    GtkWidget* control_buttons_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 2);
    GtkWidget* hide_button_ = gtk_button_new_with_label("👁 ");
    GtkWidget* locate_button = gtk_button_new_with_label("🎯 ");
    GtkWidget* close_button = gtk_button_new_with_label("✕ ");
    g_signal_connect(hide_button_, "clicked", G_CALLBACK(on_hide_button_clicked), window_);

    
    g_signal_connect(locate_button, "clicked", G_CALLBACK(ConsentWindow::on_locate_window_clicked), this);
    g_signal_connect(close_button, "clicked", G_CALLBACK(on_close_button_clicked), window_);
    gtk_box_pack_start(GTK_BOX(control_buttons_hbox), hide_button_, TRUE, TRUE, 0);
    
    
    gtk_box_pack_start(GTK_BOX(control_buttons_hbox), locate_button, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(control_buttons_hbox), close_button, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(vbox_), control_buttons_hbox, FALSE, FALSE, 0);

    // Brightness control: horizontal scrollbar (slider)
    // Range 0-100 for finer control at the low end (will be divided by 100 in callback)
    GtkWidget* brightness_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 4);
    GtkWidget* brightness_label = gtk_label_new("Brightness:");
    GtkWidget* brightness_scale = gtk_scale_new_with_range(GTK_ORIENTATION_HORIZONTAL, 0, 100, 1);
    gtk_scale_set_value_pos(GTK_SCALE(brightness_scale), GTK_POS_RIGHT);
    gtk_range_set_value(GTK_RANGE(brightness_scale), 3); // Initial value: 3 (translates to 0.03 opacity)
    gtk_widget_set_size_request(brightness_scale, 120, -1);
    g_signal_connect(brightness_scale, "value-changed", G_CALLBACK(on_brightness_changed), window_);
    gtk_box_pack_start(GTK_BOX(brightness_hbox), brightness_label, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(brightness_hbox), brightness_scale, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(vbox_), brightness_hbox, FALSE, FALSE, 0);

    // Indicator: dot + text using markup (compact version on same line as start/stop)
    indicator_label_ = gtk_label_new(nullptr);
    // initial: idle (gray dot) - smaller format for inline display
    gtk_label_set_markup(GTK_LABEL(indicator_label_),
        "<span font_desc='18'><span foreground='#888888'>●</span></span>\n<span font_desc='8'>Idle</span>");
    gtk_label_set_justify(GTK_LABEL(indicator_label_), GTK_JUSTIFY_CENTER);

    // Compact horizontal layout: indicator + start/stop buttons on same line
    GtkWidget* control_compact_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 2);
    gtk_box_pack_start(GTK_BOX(control_compact_hbox), indicator_label_, FALSE, FALSE, 0);
    
    start_button_ = gtk_button_new_with_label("Start");
    stop_button_ = gtk_button_new_with_label("Stop");
    gtk_widget_set_sensitive(stop_button_, FALSE); // disabled until recording starts
    
    gtk_box_pack_start(GTK_BOX(control_compact_hbox), start_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(control_compact_hbox), stop_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(vbox_), control_compact_hbox, FALSE, FALSE, 0);

    // Screenshot buttons
    GtkWidget* screenshot_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 4);
    screenshot_button_ = gtk_button_new_with_label("📷");
    screenshot_area_button_ = gtk_button_new_with_label("📷▭");
    //gtk_widget_set_tooltip_text(screenshot_button_, "Capture full screen");
    //gtk_widget_set_tooltip_text(screenshot_area_button_, "Capture area (with OCR)");

    gtk_box_pack_start(GTK_BOX(screenshot_hbox), screenshot_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(screenshot_hbox), screenshot_area_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(vbox_), screenshot_hbox, FALSE, FALSE, 0);

    // Stream button (for Android phone screen sharing)
    GtkWidget* stream_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 2);
    stream_button_ = gtk_button_new_with_label("📡 ");
    stop_stream_button_ = gtk_button_new_with_label("⏹");
    gtk_widget_set_sensitive(stop_stream_button_, FALSE); // disabled until streaming starts
   // gtk_widget_set_tooltip_text(stream_button_, "Start streaming screen to Android phone");
    gtk_box_pack_start(GTK_BOX(stream_hbox), stream_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(stream_hbox), stop_stream_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(vbox_), stream_hbox, FALSE, FALSE, 0);

    // ===== GEMINI CHAT UI =====
    GtkWidget* chat_separator = gtk_separator_new(GTK_ORIENTATION_HORIZONTAL);
    gtk_box_pack_start(GTK_BOX(vbox_), chat_separator, FALSE, FALSE, 0);
    
    GtkWidget* chat_label = gtk_label_new("<b> ...</b>");
    gtk_label_set_use_markup(GTK_LABEL(chat_label), TRUE);
    gtk_box_pack_start(GTK_BOX(vbox_), chat_label, FALSE, FALSE, 0);

    // Chat response text view (scrolled) - 50% of available space
    GtkWidget* scroll_window = gtk_scrolled_window_new(nullptr, nullptr);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_widget_set_size_request(scroll_window, -1, 150);  // Reduced from 200 to 150
    gtk_widget_set_hexpand(scroll_window, TRUE);
    gtk_widget_set_vexpand(scroll_window, TRUE);  // Allow to expand vertically
    
    chat_text_view_ = gtk_text_view_new();
    gtk_text_view_set_editable(GTK_TEXT_VIEW(chat_text_view_), FALSE);
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(chat_text_view_), GTK_WRAP_WORD);
    gtk_container_add(GTK_CONTAINER(scroll_window), chat_text_view_);
    gtk_box_pack_start(GTK_BOX(vbox_), scroll_window, TRUE, TRUE, 0);

    // Input area (now uses GtkTextView for multi-line support with formatting) - 50% of available space
    GtkWidget* input_scroll = gtk_scrolled_window_new(nullptr, nullptr);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(input_scroll), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_widget_set_size_request(input_scroll, -1, 120);  // Increased from 80 to 120
    gtk_widget_set_hexpand(input_scroll, TRUE);
    gtk_widget_set_vexpand(input_scroll, TRUE);  // Allow to expand vertically
    
    // Create text view for input (supports multi-line)
    GtkWidget* input_text_view = gtk_text_view_new();
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(input_text_view), GTK_WRAP_WORD);
    gtk_text_view_set_left_margin(GTK_TEXT_VIEW(input_text_view), 5);
    gtk_text_view_set_right_margin(GTK_TEXT_VIEW(input_text_view), 5);
    
    // Store reference to input text view (we'll use it instead of entry)
    input_entry_ = input_text_view;  // Reuse the field name for compatibility
    
    GtkTextBuffer* input_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(input_text_view));
    gtk_text_buffer_set_text(input_buffer, "", -1);
    
    gtk_container_add(GTK_CONTAINER(input_scroll), input_text_view);
    gtk_box_pack_start(GTK_BOX(vbox_), input_scroll, TRUE, TRUE, 0);

    // Send button (between chat and input for easier access, full width)
    ask_button_ = gtk_button_new_with_label("📤 ");
    gtk_widget_set_hexpand(ask_button_, TRUE);
    gtk_box_pack_start(GTK_BOX(vbox_), ask_button_, FALSE, FALSE, 2);

    // Clear and Copy buttons (operate on chat text view)
    GtkWidget* control_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 4);
    clear_button_ = gtk_button_new_with_label("🗑️ ");
    paste_button_ = gtk_button_new_with_label("📋 ");
    GtkWidget* transcribe_button = gtk_button_new_with_label("� ");
    // Save chat button (next to transcribe)
    GtkWidget* save_chat_button = gtk_button_new_with_label("💾 ");
    //gtk_widget_set_tooltip_text(clear_button_, "Clear chat display");
    //gtk_widget_set_tooltip_text(paste_button_, "Copy chat display to clipboard");
    //gtk_widget_set_tooltip_text(transcribe_button, "Transcribe last recording and load into input box");
    gtk_box_pack_start(GTK_BOX(control_hbox), clear_button_, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(control_hbox), paste_button_, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(control_hbox), transcribe_button, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(control_hbox), save_chat_button, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox_), control_hbox, FALSE, FALSE, 0);

    // Quick case buttons (1, 2, 3, 4)
    GtkWidget* case_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 4);
    case1_button_ = gtk_button_new_with_label("Case 1");
    case2_button_ = gtk_button_new_with_label("Case 2");
    case3_button_ = gtk_button_new_with_label("Case 3");
    case4_button_ = gtk_button_new_with_label("Case 4");
    
    //gtk_widget_set_tooltip_text(case1_button_, "just respond to the question do not analyse");
    //gtk_widget_set_tooltip_text(case2_button_, "give me just the correct function that respond to my question do not analyse");
    //gtk_widget_set_tooltip_text(case3_button_, "give me just the choice result do not analyse");
    //gtk_widget_set_tooltip_text(case4_button_, "give me just the result do not analyse");
    
    gtk_box_pack_start(GTK_BOX(case_hbox), case1_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(case_hbox), case2_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(case_hbox), case3_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(case_hbox), case4_button_, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(vbox_), case_hbox, FALSE, FALSE, 0);

    // Small status text (session info)
    status_label_ = gtk_label_new("Ready");
    gtk_box_pack_start(GTK_BOX(vbox_), status_label_, FALSE, FALSE, 0);

    // Signal connections
    g_signal_connect(window_, "destroy", G_CALLBACK(gtk_main_quit), nullptr);
    // Allow window to receive key events
    gtk_widget_set_can_focus(window_, TRUE);
    g_signal_connect(window_, "key-press-event", G_CALLBACK(ConsentWindow::on_key_press), this);
    g_signal_connect(start_button_, "clicked", G_CALLBACK(ConsentWindow::on_start_clicked), this);
    g_signal_connect(stop_button_, "clicked", G_CALLBACK(ConsentWindow::on_stop_clicked), this);
    g_signal_connect(screenshot_button_, "clicked", G_CALLBACK(ConsentWindow::on_screenshot_clicked), this);
    g_signal_connect(screenshot_area_button_, "clicked", G_CALLBACK(ConsentWindow::on_screenshot_area_clicked), this);
    g_signal_connect(stream_button_, "clicked", G_CALLBACK(ConsentWindow::on_stream_clicked), this);
    g_signal_connect(stop_stream_button_, "clicked", G_CALLBACK(ConsentWindow::on_stop_stream_clicked), this);
    
    // Gemini chat signals
    g_signal_connect(ask_button_, "clicked", G_CALLBACK(ConsentWindow::on_ask_clicked), this);
    g_signal_connect(clear_button_, "clicked", G_CALLBACK(ConsentWindow::on_clear_clicked), this);
    g_signal_connect(paste_button_, "clicked", G_CALLBACK(ConsentWindow::on_paste_clicked), this);
    g_signal_connect(transcribe_button, "clicked", G_CALLBACK(ConsentWindow::on_transcribe_clicked), this);
    g_signal_connect(save_chat_button, "clicked", G_CALLBACK(ConsentWindow::on_save_chat_clicked), this);
    g_signal_connect(transcribe_button, "clicked", G_CALLBACK(ConsentWindow::on_transcribe_clicked), this);
    g_signal_connect(case1_button_, "clicked", G_CALLBACK(ConsentWindow::on_case1_clicked), this);
    g_signal_connect(case2_button_, "clicked", G_CALLBACK(ConsentWindow::on_case2_clicked), this);
    g_signal_connect(case3_button_, "clicked", G_CALLBACK(ConsentWindow::on_case3_clicked), this);
    g_signal_connect(case4_button_, "clicked", G_CALLBACK(ConsentWindow::on_case4_clicked), this);

    // Initialize uploader and audio capture singletons (uploads optional)
    const char* upload_url = getenv("ETHICS_ASSISTANT_UPLOAD_URL");
    const char* api_key = getenv("ETHICS_ASSISTANT_API_KEY");
    if(!upload_url) upload_url = ""; // empty -> uploader disabled
    g_uploader = new Uploader(std::string(upload_url), std::string(api_key ? api_key : ""));
    g_audio_capture = new AudioCapture();
    g_audio_encoder = new AudioEncoder();
    
    // Initialize conversation history
    history_file_path_ = "/home/dell/recordings/conversation_history.json";
    load_conversation_history(history_file_path_);
    
    // PERMANENTLY disable system bell/buzzer at startup (does not affect microphone)
    suppress_all_system_bells();
    if (g_logger) g_logger->log("✓ System buzzer/bell sounds disabled (microphone audio still ON)");    
    if (g_logger) {
        g_logger->log("ConsentWindow initialized with audio capture, encoder, and screenshot/OCR");
        g_logger->log("Conversation history loaded from: " + history_file_path_);
    }

    // Start global hotkey thread (Ctrl+U) to move cursor inside the frame
    global_hotkey_running_.store(true);
    global_hotkey_thread_ = std::make_unique<std::thread>([this]() {
        // Open X display on this thread
        Display* dpy = XOpenDisplay(nullptr);
        if (!dpy) return;

        Window root = DefaultRootWindow(dpy);

        // Ctrl+U
        int keycode = XKeysymToKeycode(dpy, XStringToKeysym("U"));
        unsigned int modifiers = ControlMask;

        // Try to grab the key (allow for NumLock/Mod2 by grabbing multiple modifier combos)
        unsigned int mods[] = {0, Mod2Mask};
        for (unsigned int m : mods) {
            XGrabKey(dpy, keycode, modifiers | m, root, True, GrabModeAsync, GrabModeAsync);
        }
        XSelectInput(dpy, root, KeyPressMask);
        XEvent ev;

        while (global_hotkey_running_.load()) {
            if (XPending(dpy)) {
                XNextEvent(dpy, &ev);
                if (ev.type == KeyPress) {
                    XKeyEvent* kev = (XKeyEvent*)&ev;
                    KeySym ks = 0;
                    XkbLookupKeySym(dpy, kev->keycode, kev->state, nullptr, &ks);
                    if ((ks == XK_u || ks == XK_U) && (kev->state & ControlMask)) {
                        // Post idle callback to move cursor in GTK main thread
                        gdk_threads_add_idle_full(G_PRIORITY_DEFAULT_IDLE, [](gpointer data) -> gboolean {
                            ConsentWindow* self = static_cast<ConsentWindow*>(data);
                            if (!self) return FALSE;
                            self->center_cursor_in_window();
                            return FALSE;
                        }, this, nullptr);
                    }
                }
            } else {
                // Sleep briefly to avoid busy loop
                std::this_thread::sleep_for(std::chrono::milliseconds(50));
            }
        }

        // Ungrab before exit
        for (unsigned int m : mods) {
            XUngrabKey(dpy, keycode, modifiers | m, root);
        }
        XCloseDisplay(dpy);
    });
}

ConsentWindow::~ConsentWindow() {
    // Ensure capture stopped and encoder finalized
    if (g_is_recording.load() && g_audio_capture) {
        g_audio_capture->stop();
        g_is_recording.store(false);
    }
    if (g_audio_encoder) {
        g_audio_encoder->finalize();
        delete g_audio_encoder;
        g_audio_encoder = nullptr;
    }
    if (g_audio_capture) { delete g_audio_capture; g_audio_capture = nullptr; }
    if (g_uploader) { delete g_uploader; g_uploader = nullptr; }
    // Destroy GTK widgets (GTK handles most cleanup on program exit)

    // Stop global hotkey thread
    if (global_hotkey_running_.load()) {
        global_hotkey_running_.store(false);
        if (global_hotkey_thread_ && global_hotkey_thread_->joinable()) {
            global_hotkey_thread_->join();
        }
        global_hotkey_thread_.reset();
    }
}

// ---- Conversation History Management ----
void ConsentWindow::add_to_conversation_history(const std::string& role, const std::string& content) {
    conversation_history_.push_back({role, content});
    // Auto-save after each message
    save_conversation_history(history_file_path_);
}

void ConsentWindow::save_conversation_history(const std::string& filepath) {
    std::string path = filepath.empty() ? history_file_path_ : filepath;
    try {
        json history_array = json::array();
        for (const auto& msg : conversation_history_) {
            history_array.push_back({
                {"role", msg.role},
                {"content", msg.content}
            });
        }
        
        json history_obj;
        history_obj["messages"] = history_array;
        history_obj["timestamp"] = std::chrono::system_clock::now().time_since_epoch().count();
        
        std::ofstream ofs(path);
        ofs << history_obj.dump(2);
        ofs.close();
        
        if (g_logger) {
            g_logger->log("Conversation history saved to: " + path);
        }
    } catch (const std::exception& e) {
        if (g_logger) {
            std::string msg = std::string("Failed to save conversation history: ") + e.what();
            g_logger->log(msg);
        }
    }
}

void ConsentWindow::load_conversation_history(const std::string& filepath) {
    std::string path = filepath.empty() ? history_file_path_ : filepath;
    try {
        std::ifstream ifs(path);
        if (!ifs.good()) {
            if (g_logger) {
                g_logger->log("No previous conversation history found at: " + path);
            }
            return;
        }
        
        json history_obj;
        ifs >> history_obj;
        ifs.close();
        
        conversation_history_.clear();
        if (history_obj.contains("messages") && history_obj["messages"].is_array()) {
            for (const auto& msg : history_obj["messages"]) {
                if (msg.contains("role") && msg.contains("content")) {
                    conversation_history_.push_back({
                        msg["role"].get<std::string>(),
                        msg["content"].get<std::string>()
                    });
                }
            }
        }
        
        if (g_logger) {
            std::string msg = std::string("Conversation history loaded: ") + std::to_string(conversation_history_.size()) + " messages";
            g_logger->log(msg);
        }
    } catch (const std::exception& e) {
        if (g_logger) {
            std::string msg = std::string("Failed to load conversation history: ") + e.what();
            g_logger->log(msg);
        }
    }
}

void ConsentWindow::clear_conversation_history() {
    conversation_history_.clear();
    if (g_logger) {
        g_logger->log("Conversation history cleared");
    }
}

// ---- show window ----
void ConsentWindow::show() {
    gtk_widget_show_all(window_);
}

// ---- hide window ----
void ConsentWindow::hide() {
    gtk_widget_hide(window_);
}

// ---- helper: update visual state ----
void ConsentWindow::set_recording_state(bool recording) {
    if (recording) {
        // red dot and "Recording" text
        gtk_label_set_markup(GTK_LABEL(indicator_label_),
            "<span font_desc='36'>\n<span foreground='#d9534f'>●</span>\n</span>\n<span font_desc='9' foreground='#d9534f'>Recording</span>");
        gtk_widget_set_sensitive(start_button_, FALSE);
        gtk_widget_set_sensitive(stop_button_, TRUE);
        gtk_label_set_text(GTK_LABEL(status_label_), "Recording — visible indicator ON");
        gtk_window_set_title(GTK_WINDOW(window_), "Recorder — RECORDING");
    } else {
        // gray dot and "Idle" text
        gtk_label_set_markup(GTK_LABEL(indicator_label_),
            "<span font_desc='36'>\n<span foreground='#888888'>●</span>\n</span>\n<span font_desc='9'>Idle</span>");
        gtk_widget_set_sensitive(start_button_, TRUE);
        gtk_widget_set_sensitive(stop_button_, FALSE);
        gtk_label_set_text(GTK_LABEL(status_label_), "Ready");
        gtk_window_set_title(GTK_WINDOW(window_), "Recorder");
    }
}

// ---- Callbacks ----
// Start button clicked: show explicit consent dialog, then start capture
void ConsentWindow::on_start_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    if (g_is_recording.load()) return;

    // Start recording immediately without showing an explicit consent popup
    if (g_logger) g_logger->log("Starting recording (no consent popup)");

    // Get output settings from config
    std::string output_dir = "/tmp/ethical_recordings";
    int sample_rate = 16000;
    int channels = 1;
    
    if (self->config_) {
        output_dir = self->config_->get_string("output_dir", output_dir);
        sample_rate = self->config_->get_int("sample_rate", sample_rate);
        channels = self->config_->get_int("channels", channels);
    }
    
    // Create output filename with timestamp
    auto now = std::chrono::system_clock::now();
    std::time_t t = std::chrono::system_clock::to_time_t(now);
    char filename_buf[256];
    std::strftime(filename_buf, sizeof(filename_buf), "recording_%Y%m%d_%H%M%S.wav", std::localtime(&t));
    std::string output_file = output_dir + "/" + filename_buf;
    
    if (g_logger) {
        g_logger->log("Recording to: " + output_file);
    }

    // Initialize encoder
    if (!g_audio_encoder->init(output_file, sample_rate, channels)) {
        if (g_logger) g_logger->log("ERROR: Failed to initialize audio encoder");
        return;
    }

    // Prepare callback to receive PCM chunks from AudioCapture
    auto cb = [](const uint8_t* data, size_t len, uint64_t pts_ms) {
        (void)pts_ms;
        if (g_audio_encoder) {
            bool ok = g_audio_encoder->encode(data, len);
            if (!ok && g_logger) {
                g_logger->log("WARNING: Failed to encode audio chunk");
            }
        }
    };

    // Start audio capture
    if (g_audio_capture) {
        bool started = g_audio_capture->start(cb);
        if (!started) {
            if (g_logger) g_logger->log("ERROR: Failed to start audio capture");

            return;
        }
    } else {
        if (g_logger) g_logger->log("ERROR: Audio capture not initialized");
        return;
    }

    // update state & UI
    g_is_recording.store(true);
    self->set_recording_state(true);
    if (g_logger) g_logger->log("Audio recording started");
}

// Stop button clicked: stop capture and inform user
void ConsentWindow::on_stop_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    if (!g_is_recording.load()) return;

    if (g_logger) g_logger->log("Stopping audio recording...");

    // Stop capture
    if (g_audio_capture) {
        g_audio_capture->stop();
    }
    
    // Finalize encoder (writes trailer and closes file)
    if (g_audio_encoder) {
        g_audio_encoder->finalize();
    }
    
    // Attempt to set last recording path to the most recent .wav in output dir
    try {
        std::string outdir = "/home/dell/recordings";
        if (self->config_) outdir = self->config_->get_string("output_dir", outdir);
        std::string latest;
        std::time_t latest_t = 0;
        for (const auto& e : std::filesystem::directory_iterator(outdir)) {
            std::string f = e.path().string();
            if (f.size() > 4 && f.substr(f.size()-4) == ".wav") {
                auto wt = std::filesystem::last_write_time(e);
                auto sctp = std::chrono::time_point_cast<std::chrono::system_clock::duration>(
                    wt - std::filesystem::file_time_type::clock::now() + std::chrono::system_clock::now());
                std::time_t t = std::chrono::system_clock::to_time_t(sctp);
                if (t > latest_t) { latest_t = t; latest = f; }
            }
        }
        if (!latest.empty()) {
            self->last_recording_path_ = latest;
            if (g_logger) g_logger->log("Last recording set: " + latest);
        }
    } catch (const std::exception& e) {
        if (g_logger) g_logger->log(std::string("Error finding last recording: ") + e.what());
    }

    g_is_recording.store(false);
    self->set_recording_state(false);

    if (g_logger) g_logger->log("Audio recording stopped and file saved");

    // Inform user where data was stored
    // Instead of showing a popup, append a system message to the chat
    append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", "Recording stopped. Audio file has been saved.");
}

// In the on_screenshot_clicked callback - APPEND MODE

void ConsentWindow::on_screenshot_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self || !self->screenshot_capture_ || !self->ocr_analyzer_) return;

    std::string output_dir = "/home/dell/recordings";
    if (self->config_) {
        output_dir = self->config_->get_string("output_dir", output_dir);
    }

    // Use high-precision timestamp (microseconds) to ensure unique filenames
    auto now = std::chrono::system_clock::now();
    auto duration = now.time_since_epoch();
    auto micros = std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
    
    // Create screenshot filename with unique timestamp
    char filename_buf[256];
    snprintf(filename_buf, sizeof(filename_buf), "screenshot_%lld.png", (long long)micros);
    std::string screenshot_file = output_dir + "/" + filename_buf;
    
    // Create text output filename with same timestamp to keep them paired
    char text_filename_buf[256];
    snprintf(text_filename_buf, sizeof(text_filename_buf), "screenshot_text_%lld", (long long)micros);
    std::string text_output_file = output_dir + "/" + text_filename_buf;

    if (g_logger) g_logger->log("📷 Capturing full screen to: " + screenshot_file);

    auto screenshot_callback = [self, text_output_file, output_dir](const std::string& screenshot_path, bool success) {
        if (!success) {
            if (g_logger) g_logger->log("❌ Screenshot capture failed");
            append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", "❌ Failed to capture screenshot");
            return;
        }

        if (g_logger) g_logger->log("✅ Screenshot captured: " + screenshot_path);
        append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", "📷 Screenshot captured. Running HIGH-QUALITY OCR (PSM 3)...");

        // Run OCR on the screenshot
        auto ocr_callback = [self, screenshot_path, text_output_file, output_dir](const std::string& text, bool ocr_success) {
            if (!ocr_success) {
                if (g_logger) g_logger->log("❌ OCR analysis failed");
                append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", 
                    "❌ OCR extraction failed. Check image quality or tesseract installation.");
                return;
            }

            if (text.empty()) {
                if (g_logger) g_logger->log("⚠️ OCR returned empty text - image may have no readable text");
                append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", 
                    "⚠️ OCR could not find any text in the screenshot.\n"
                    "The image might be:\n"
                    "  • Too small or blurry\n"
                    "  • Contain only images/icons\n"
                    "  • In an unsupported language\n\n"
                    "Try capturing a different area with clearer text.");
                return;
            }

            if (g_logger) {
                g_logger->log("✅ OCR extraction successful: " + std::to_string(text.length()) + " chars");
                g_logger->log("Preview: " + text.substr(0, 300));
            }
            
            // APPEND OCR text to input (instead of overwriting)
            gdk_threads_add_idle([](gpointer data) -> gboolean {
                auto* state = static_cast<std::pair<ConsentWindow*, std::string>*>(data);
                ConsentWindow* window = state->first;
                std::string ocr_text = state->second;

                // Get current input text
                std::string current_input = get_input_text(window->input_entry_);
                
                // APPEND new OCR text with separator
                std::string separator = "\n\n--- Screenshot OCR (added) ---\n";
                std::string new_input = current_input + separator + ocr_text;
                
                // Load appended text into input box
                set_input_text(window->input_entry_, new_input);

                // Append confirmation with stats
                append_to_chat(GTK_TEXT_VIEW(window->get_chat_text_view()), "System",
                    "✅ OCR text APPENDED! (" + std::to_string(ocr_text.length()) + " new characters)\n"
                    "Total input: " + std::to_string(new_input.length()) + " characters\n\n"
                    "Ready to:\n"
                    "1. Edit/modify the combined text\n"
                    "2. Click '📤' to send all to Gemini\n"
                    "3. Use Case 1-4 for analysis\n"
                    "4. Take more screenshots to append more!");

                delete state;
                return FALSE;
            }, new std::pair<ConsentWindow*, std::string>(self, text));
        };

        if (self->ocr_analyzer_) {
            self->ocr_analyzer_->analyze_and_save(screenshot_path, text_output_file, ocr_callback);
        }
    };

    self->screenshot_capture_->capture_screen(screenshot_file, screenshot_callback);
}

// In the on_screenshot_area_clicked callback - APPEND MODE

void ConsentWindow::on_screenshot_area_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self || !self->screenshot_capture_ || !self->ocr_analyzer_) return;

    std::string output_dir = "/home/dell/recordings";
    if (self->config_) {
        output_dir = self->config_->get_string("output_dir", output_dir);
    }

    // Use high-precision timestamp (microseconds) to ensure unique filenames
    auto now = std::chrono::system_clock::now();
    auto duration = now.time_since_epoch();
    auto micros = std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
    
    // Create screenshot filename with unique timestamp
    char filename_buf[256];
    snprintf(filename_buf, sizeof(filename_buf), "screenshot_area_%lld.png", (long long)micros);
    std::string screenshot_file = output_dir + "/" + filename_buf;
    
    // Create text output filename with same timestamp
    char text_filename_buf[256];
    snprintf(text_filename_buf, sizeof(text_filename_buf), "screenshot_text_%lld", (long long)micros);
    std::string text_output_file = output_dir + "/" + text_filename_buf;

    if (g_logger) g_logger->log("📷 Capturing screen area to: " + screenshot_file);

    auto screenshot_callback = [self, text_output_file, output_dir](const std::string& screenshot_path, bool success) {
        // Restore window visibility after screenshot completes
        gdk_threads_add_idle([](gpointer data) -> gboolean {
            ConsentWindow* window = static_cast<ConsentWindow*>(data);
            gtk_widget_set_opacity(window->window_, 0.03);  // Restore to dim opacity
            return FALSE;
        }, self);

        if (!success) {
            if (g_logger) g_logger->log("❌ Area screenshot capture failed");
            append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", "❌ Failed to capture screen area");
            return;
        }

        if (g_logger) g_logger->log("✅ Screenshot area captured");

        // Now run OCR on the screenshot
        auto ocr_callback = [self, screenshot_path, text_output_file, output_dir](const std::string& text, bool ocr_success) {
            if (!ocr_success) {
                if (g_logger) g_logger->log("❌ OCR analysis failed");
                append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", "❌ OCR extraction failed");
                return;
            }

            if (text.empty()) {
                if (g_logger) g_logger->log("⚠️ OCR returned empty text");
                append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", 
                    "⚠️ OCR could not find text in the area. Try selecting a larger area with clearer text.");
                return;
            }

            if (g_logger) g_logger->log("✅ OCR extraction successful: " + std::to_string(text.length()) + " chars");
            
            // APPEND OCR text to input (instead of overwriting)
            gdk_threads_add_idle([](gpointer data) -> gboolean {
                auto* state = static_cast<std::pair<ConsentWindow*, std::string>*>(data);
                ConsentWindow* window = state->first;
                std::string ocr_text = state->second;
                
                // Get current input text
                std::string current_input = get_input_text(window->input_entry_);
                
                // APPEND new OCR text with separator
                std::string separator = "\n\n--- Area Screenshot OCR (added) ---\n";
                std::string new_input = current_input + separator + ocr_text;
                
                // Populate the input entry with APPENDED text
                set_input_text(window->input_entry_, new_input);
                
                // Show confirmation
                append_to_chat(GTK_TEXT_VIEW(window->get_chat_text_view()), "System", 
                    "✅ Area OCR APPENDED! (" + std::to_string(ocr_text.length()) + " new chars)\n"
                    "Total input: " + std::to_string(new_input.length()) + " characters\n\n"
                    "You can now:\n"
                    "1. Edit/combine the text\n"
                    "2. Click '📤' to ask Gemini\n"
                    "3. Take more screenshots to append more");
                
                delete state;
                return FALSE;
            }, new std::pair<ConsentWindow*, std::string>(self, text));
        };

        if (self->ocr_analyzer_) {
            self->ocr_analyzer_->analyze_and_save(screenshot_path, text_output_file, ocr_callback);
        }
    };

    // Hide window completely (opacity = 0) so it doesn't appear in the screenshot
    gtk_widget_set_opacity(self->window_, 0.0);
    
    self->screenshot_capture_->capture_area(screenshot_file, screenshot_callback);
}

// Stream button clicked: start WebSocket screen streaming to Android

void ConsentWindow::on_stream_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    if (g_logger) {
        g_logger->log("📡 Stream button clicked - starting screen stream");
        g_logger->log("📡 Screen Streaming Started - streaming console window to Android");
        g_logger->log("Server: ws://localhost:8765/stream");
        g_logger->log("To connect from Android:");
        g_logger->log("  1. Get your Ubuntu IP: hostname -I");
        g_logger->log("  2. Open Screen Viewer app on Android");
        g_logger->log("  3. Enter your IP address");
        g_logger->log("  4. Click 'Connect'");
        g_logger->log("All buttons on phone will control this app!");
    } 
    // Extra suppression of system sounds during streaming
    // DO NOT MUTE MICROPHONE OR AUDIO OUTPUT - only disable the bell/buzzer sound
    // The buzzer is a visual/error bell, NOT the microphone audio 
    // Set all bell/beep sounds to silent (not the microphone)
    system("gsettings set org.cinnamon.desktop.sound effects-volume 0 2>/dev/null &");
    system("gsettings set org.gnome.desktop.sound effects-volume 0 2>/dev/null &");
    system("gsettings set org.mate.sound volume-sound 0 2>/dev/null &");  
    // Disable all GTK error/warning sounds (not microphone)
    g_object_set(gtk_settings_get_default(), "gtk-error-bell", FALSE, NULL);
    g_object_set(gtk_settings_get_default(), "gtk-enable-input-feedback-sounds", FALSE, NULL);
    if (g_logger) g_logger->log("✓ System buzzer/bell sounds disabled (microphone audio still ON)");
    // Initialize and start ScreenStreamer
    self->screen_streamer_ = std::make_unique<ScreenStreamer>(8765); 
    // Get GTK window ID (XWindow ID)
    GdkWindow* gdk_window = gtk_widget_get_window(self->window_);
    if (gdk_window) {
        unsigned long window_id = gdk_x11_window_get_xid(gdk_window);
        self->screen_streamer_->set_window_id(window_id);
        if (g_logger) g_logger->log("GTK Window ID: " + std::to_string(window_id));
    }    
    // Set command handler to receive button clicks from Android
    self->screen_streamer_->set_command_handler([self](const std::string& command) {
        // Parse command JSON and execute corresponding button click
        // Format: {"type":"button_click","button":"start"} or {"type":"text_input","text":"..."}
        if (g_logger) g_logger->log("📱 Android command: " + command);       
        // Cast GtkWidget* to GtkButton* when calling handlers
        if (command.find("start") != std::string::npos) {
            ConsentWindow::on_start_clicked(GTK_BUTTON(self->start_button_), self);
        } else if (command.find("stop") != std::string::npos) {
            ConsentWindow::on_stop_clicked(GTK_BUTTON(self->stop_button_), self);
        } else if (command.find("screenshot") != std::string::npos) {
            ConsentWindow::on_screenshot_clicked(GTK_BUTTON(self->screenshot_button_), self);
        } else if (command.find("ask") != std::string::npos) {
            ConsentWindow::on_ask_clicked(GTK_BUTTON(self->ask_button_), self);
        } else if (command.find("clear") != std::string::npos) {
            ConsentWindow::on_clear_clicked(GTK_BUTTON(self->clear_button_), self);
        } else if (command.find("case1") != std::string::npos) {
            ConsentWindow::on_case1_clicked(GTK_BUTTON(self->case1_button_), self);
        }
    });   
    self->screen_streamer_->start();    
    if (g_logger) g_logger->log("✅ Screen streaming setup complete - waiting for Android connections");  
    // Enable stop stream button, disable stream button
    gtk_widget_set_sensitive(self->stream_button_, FALSE);
    gtk_widget_set_sensitive(self->stop_stream_button_, TRUE);
}

// Stop stream button clicked: stop WebSocket screen streaming
void ConsentWindow::on_stop_stream_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;

    if (g_logger) {
        g_logger->log("⏹ Stop Stream button clicked - stopping screen stream");
    }
    
    // Stop the streamer if it exists
    if (self->screen_streamer_) {
        self->screen_streamer_->stop();
        self->screen_streamer_.reset();  // Clean up the streamer
    }
    
    // Disable stop stream button, enable stream button
    gtk_widget_set_sensitive(self->stop_stream_button_, FALSE);
    gtk_widget_set_sensitive(self->stream_button_, TRUE);
    
    if (g_logger) g_logger->log("✅ Screen streaming stopped");
}

// Locate window button clicked: center window and make it visible
void ConsentWindow::on_locate_window_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    
    self->center_cursor_in_window();
    if (g_logger) g_logger->log("✓ Cursor moved to center of frame");
}

// ===== GEMINI CHAT CALLBACKS =====

// Helper function to append text to chat display
static void append_to_chat(GtkTextView* text_view, const std::string& sender, const std::string& message) {
    GtkTextBuffer* buffer = gtk_text_view_get_buffer(text_view);
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(buffer, &end);
    
    std::string formatted = std::string(sender) + ":\n" + message + "\n\n";
    gtk_text_buffer_insert(buffer, &end, formatted.c_str(), -1);
    
    // Auto-scroll to bottom
    gtk_text_view_scroll_to_iter(text_view, &end, 0.0, FALSE, 0.0, 1.0);
}

// Helper function to query Gemini and display response (with buffered streaming)
static void query_gemini_and_display(ConsentWindow* self, const std::string& question) {
    if (!self || !self->get_ai_service()) {
        if (g_logger) g_logger->log("ERROR: Invalid window or AI service");
        append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", "❌ AI service not available");
        return;
    }
    
    if (g_logger) g_logger->log("Querying Gemini with streaming: " + question.substr(0, 100));
    
    // Add user question to conversation history
    self->add_to_conversation_history("user", question);
    
    // Use shared state to avoid reference capture issues
    struct StreamState {
        std::string buffer;
        std::chrono::steady_clock::time_point start_time = std::chrono::steady_clock::now();
        std::chrono::steady_clock::time_point last_update = std::chrono::steady_clock::now();
        std::string full_response;
        bool timer_shown = false;
    };
    
    auto stream_state = std::make_shared<StreamState>();
    const std::chrono::milliseconds UPDATE_INTERVAL(100); // Update UI every 100ms max
    
    // Run in background thread to avoid blocking UI
    std::thread([self, question, stream_state, UPDATE_INTERVAL]() {
        // Build prompt with conversation history context (like ChatGPT does)
        std::string context_prompt;
        const auto& history = self->get_conversation_history();
        
        // Build context from previous messages (skip the current one we just added)
        if (history.size() > 1) {
            context_prompt = "Previous conversation context:\n";
            // Include up to last 10 messages for context window
            size_t start_idx = history.size() > 21 ? history.size() - 21 : 0; // Keep ~10 turns (user+assistant pairs)
            for (size_t i = start_idx; i < history.size() - 1; ++i) { // -1 to skip the current question
                context_prompt += "[" + history[i].role + "]: " + history[i].content.substr(0, 200) + "\n";
            }
            context_prompt += "\nCurrent question: " + question;
        } else {
            context_prompt = question;
        }
        
        // Callback uses shared_ptr to safely access state
        auto stream_callback = [self, stream_state, UPDATE_INTERVAL](const std::string& chunk, bool success) {
            if (!success || chunk.empty()) return;
            
            stream_state->buffer += chunk;
            auto now = std::chrono::steady_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - stream_state->start_time).count();
            
            // Show timer on first chunk
            if (!stream_state->timer_shown) {
                stream_state->timer_shown = true;
                gdk_threads_add_idle([](gpointer data) -> gboolean {
                    auto* state = static_cast<std::pair<ConsentWindow*, std::string>*>(data);
                    ConsentWindow* window = state->first;
                    std::string timer_msg = state->second;
                    
                    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(window->get_chat_text_view()));
                    GtkTextIter end;
                    gtk_text_buffer_get_end_iter(buf, &end);
                    gtk_text_buffer_insert(buf, &end, timer_msg.c_str(), -1);
                    gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(window->get_chat_text_view()), &end, 0.0, FALSE, 0.0, 1.0);
                    
                    delete state;
                    return FALSE;
                }, new std::pair<ConsentWindow*, std::string>(self, "(" + std::to_string(elapsed) + ")...\n"));
            }
            
            // Only update UI if buffer is large enough or enough time has passed
            if (stream_state->buffer.size() > 500 || (now - stream_state->last_update) > UPDATE_INTERVAL) {
                stream_state->full_response += stream_state->buffer;
                std::string to_display = stream_state->buffer;
                stream_state->buffer.clear();
                stream_state->last_update = now;
                
                // Update UI on main thread
                gdk_threads_add_idle([](gpointer data) -> gboolean {
                    auto* state = static_cast<std::pair<ConsentWindow*, std::string>*>(data);
                    ConsentWindow* window = state->first;
                    std::string text = state->second;
                    
                    // Append to chat display
                    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(window->get_chat_text_view()));
                    GtkTextIter end;
                    gtk_text_buffer_get_end_iter(buf, &end);
                    gtk_text_buffer_insert(buf, &end, text.c_str(), -1);
                    
                    // Auto-scroll to bottom
                    gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(window->get_chat_text_view()), &end, 0.0, FALSE, 0.0, 1.0);
                    
                    delete state;
                    return FALSE;
                }, new std::pair<ConsentWindow*, std::string>(self, to_display));
            }
        };
        
        // Send the context-aware prompt with history
        self->get_ai_service()->ask_question(context_prompt, stream_callback);
        
        // Flush any remaining buffered text
        if (!stream_state->buffer.empty()) {
            stream_state->full_response += stream_state->buffer;
            std::string to_display = stream_state->buffer;
            stream_state->buffer.clear();
            
            gdk_threads_add_idle([](gpointer data) -> gboolean {
                auto* state = static_cast<std::pair<ConsentWindow*, std::string>*>(data);
                ConsentWindow* window = state->first;
                std::string text = state->second;
                
                GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(window->get_chat_text_view()));
                GtkTextIter end;
                gtk_text_buffer_get_end_iter(buf, &end);
                gtk_text_buffer_insert(buf, &end, text.c_str(), -1);
                gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(window->get_chat_text_view()), &end, 0.0, FALSE, 0.0, 1.0);
                
                delete state;
                return FALSE;
            }, new std::pair<ConsentWindow*, std::string>(self, to_display));
        }
        
        // Add assistant response to conversation history
        if (!stream_state->full_response.empty()) {
            self->add_to_conversation_history("assistant", stream_state->full_response);
        }
        
        if (g_logger && !stream_state->full_response.empty()) {
            g_logger->log("✅ Streaming response complete: " + std::to_string(stream_state->full_response.size()) + " bytes");
        }
    }).detach();
}



// Send button clicked
void ConsentWindow::on_ask_clicked(GtkButton* button, gpointer user_data) {
    (void)button; // Suppress unused parameter warning
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    
    std::string question = get_input_text(self->input_entry_);
    
    if (question.empty()) {
        if (g_logger) g_logger->log("Empty question - ignoring");
        return;
    }
    
    // Display user question
    append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "You", question);
    
    // Clear input
    set_input_text(self->input_entry_, "");
    
    // Query Gemini
    query_gemini_and_display(self, question);
}

// Case 1: Direct response without analysis
void ConsentWindow::on_case1_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    
    std::string input_text = get_input_text(self->input_entry_);
    if (input_text.empty()) {
        append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", 
            "⚠️ Input box is empty. Please enter your question/code first, then press Case 1.");
        return;
    }
    
    // Explicit, strict instruction: only the final answer with zero analysis
    //std::string instruction = "\n\n[INSTRUCTION]: RESPOND WITH ONLY THE FINAL ANSWER. "
                             // "ZERO analysis, explanations, reasoning, or extra text. "
                             // "No markdown formatting, code blocks, or commentary. "
                            //  "ANSWER ONLY - nothing else.";
   // std::string instruction = "\n\n[INSTRUCTION]: RESPOND WITH ONLY A PROPERLY FORMATTED COMMIT MESSAGE. "
                        //  "Format: First line starts with action word (Add/Fix/Update/Implement) followed by concise summary. "
                       //   "Next lines: Describe the component changes you made. "
                      //    "Then: List test cases covered (e.g., 'Manually tested with: empty inputs, edge cases, etc.'). "
                      //    "NO preamble, NO explanation before/after the message. "
                      //    "COMMIT MESSAGE ONLY.";
    
                          
    std::string instruction =
    "\n\n[INSTRUCTION]: You are the candidate. Detect the input language (French or English) and reply in the same language. "
    "Use the input as context and IMPROVISE realistic experience details that fit the candidate's profile and field. "
    "Do not quote or repeat the input. Do not add headings or bullets. Output only the response.";
    std::string full_prompt = input_text + instruction;
    
    set_input_text(self->input_entry_, full_prompt);
    if (g_logger) g_logger->log("Case 1: Direct response mode - draft ready");
    
    // Auto-send
    ConsentWindow::on_ask_clicked(nullptr, user_data);
}

// Case 2: Execute/run the code and give output
void ConsentWindow::on_case2_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    
    std::string input_text = get_input_text(self->input_entry_);
    if (input_text.empty()) {
        append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", 
            "⚠️ Input box is empty. Please enter your code first, then press Case 2.");
        return;
    }
    
    // Strict instruction: ONLY execution output, no explanations whatsoever
    std::string instruction = "\n\n[INSTRUCTION]: YOU MUST RESPOND WITH ONLY THE EXACT PROGRAM OUTPUT (stdout/stderr). "
                            "ZERO explanations, commentary, or code. "
                            "If the code has errors, output the error message only. "
                            "If nothing prints, output an empty line. "
                            "NOTHING BUT THE OUTPUT.";
    std::string full_prompt = input_text + instruction;
    
    set_input_text(self->input_entry_, full_prompt);
    if (g_logger) g_logger->log("Case 2: Execute/output mode - draft ready");
    
    // Auto-send
    ConsentWindow::on_ask_clicked(nullptr, user_data);
}

// Case 3: Choose/decide between options
void ConsentWindow::on_case3_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    
    std::string input_text = get_input_text(self->input_entry_);
    if (input_text.empty()) {
        append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", 
            "⚠️ Input box is empty. Please enter your options/choices first, then press Case 3.");
        return;
    }
    
    // Strict instruction: pick ONE option only, no reasoning
    std::string instruction = "\n\n[INSTRUCTION]: RESPOND WITH ONLY THE SINGLE BEST OPTION/CHOICE NAME. "
                            "NO reasoning, no explanation, no extra words. "
                            "Output the choice name/label ONLY.";
    std::string full_prompt = input_text + instruction;
    
    set_input_text(self->input_entry_, full_prompt);
    if (g_logger) g_logger->log("Case 3: Choice/decision mode - draft ready");
    
    // Auto-send
    ConsentWindow::on_ask_clicked(nullptr, user_data);
}

// Case 4: Code implementation only (for programmers)
void ConsentWindow::on_case4_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    
    std::string input_text = get_input_text(self->input_entry_);
    if (input_text.empty()) {
        append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", 
            "⚠️ Input box is empty. Please describe the function you need, then press Case 4.");
        return;
    }
    
    // Strict instruction: ONLY code, no text, no explanations
    std::string instruction = "\n\n[INSTRUCTION]: RESPOND WITH ONLY THE COMPLETE WORKING CODE/FUNCTION. "
                            "ZERO explanations, comments, descriptions, or markdown. "
                            "No code block markers (```). "
                            "NO preamble, NO epilogue. "
                            "OUTPUT THE RAW CODE ONLY - ready to copy-paste and execute immediately.";
    std::string full_prompt = input_text + instruction;
    
    set_input_text(self->input_entry_, full_prompt);
    if (g_logger) g_logger->log("Case 4: Code-only mode - draft ready");
    
    // Auto-send
    ConsentWindow::on_ask_clicked(nullptr, user_data);
}

// Clear button clicked
void ConsentWindow::on_clear_clicked(GtkButton* button, gpointer user_data) {
    (void)button; // Suppress unused parameter warning
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    // Clear entire chat display buffer
    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(self->chat_text_view_));
    if (!buf) return;
    gtk_text_buffer_set_text(buf, "", -1);
    // Also clear input entry so user has a blank box
    if (self->input_entry_) set_input_text(self->input_entry_, "");
    if (g_logger) g_logger->log("✓ Chat display and input cleared");
    std::cout << "[DEBUG] Chat display and input cleared successfully" << std::endl;
}

// Copy button clicked (copies text from input to clipboard)
void ConsentWindow::on_paste_clicked(GtkButton* button, gpointer user_data) {
    (void)button; // Suppress unused parameter warning
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    // Prefer copying chat display; if empty, copy the input entry text instead
    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(self->chat_text_view_));
    gchar* text = nullptr;
    if (buf) {
        GtkTextIter start, end;
        gtk_text_buffer_get_start_iter(buf, &start);
        gtk_text_buffer_get_end_iter(buf, &end);
        text = gtk_text_buffer_get_text(buf, &start, &end, FALSE);
    }

    if ((!text || strlen(text) == 0) && self->input_entry_) {
        std::string in = get_input_text(self->input_entry_);
        if (!in.empty()) text = g_strdup(in.c_str());
    }

    if (!text || strlen(text) == 0) {
        if (g_logger) g_logger->log("⚠️ Nothing to copy (chat and input empty)");
        std::cout << "[DEBUG] Nothing to copy (chat and input empty)" << std::endl;
        if (text) g_free(text);
        return;
    }

    GtkClipboard* clipboard = gtk_clipboard_get(GDK_SELECTION_CLIPBOARD);
    if (clipboard) {
        gtk_clipboard_set_text(clipboard, text, -1);
        gtk_clipboard_store(clipboard);
        if (g_logger) g_logger->log("✓ Copied text to clipboard");
        std::cout << "[DEBUG] Copied text to clipboard" << std::endl;
    } else {
        if (g_logger) g_logger->log("⚠️ Failed to access clipboard");
        std::cout << "[DEBUG] Failed to get clipboard" << std::endl;
    }
    g_free(text);
}

// Transcribe button clicked - transcribe last recording and load into input
void ConsentWindow::on_transcribe_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    if (!self->input_entry_) return;

    if (self->last_recording_path_.empty()) {
        if (g_logger) g_logger->log("⚠️ No recording found to transcribe");
        return;
    }

    // Run transcription script in background
    std::string script = "/home/dell/ethical_assistant/transcribe.sh";
    std::string cmd = script + " \"" + self->last_recording_path_ + "\"";
    if (g_logger) g_logger->log("Running transcription: " + cmd);

    std::thread([self, cmd]() {
        FILE* pipe = popen(cmd.c_str(), "r");
        if (!pipe) {
            if (g_logger) g_logger->log("❌ Failed to run transcription script");
            return;
        }
        std::string output;
        char buf[256];
        while (fgets(buf, sizeof(buf), pipe)) output += buf;
        pclose(pipe);

        // Try to extract transcript path from script output
        std::string marker = "Script saved to: ";
        size_t pos = output.rfind(marker);
        std::string transcript_path;
        if (pos != std::string::npos) {
            size_t start = pos + marker.size();
            size_t end = output.find('\n', start);
            if (end == std::string::npos) end = output.size();
            transcript_path = output.substr(start, end - start);
        }

        std::string transcript_text;
        if (!transcript_path.empty()) {
            std::ifstream f(transcript_path);
            if (f.is_open()) { std::ostringstream ss; ss << f.rdbuf(); transcript_text = ss.str(); }
        } else {
            transcript_text = output; // fallback to full output
        }

        // Update UI on main thread
        gdk_threads_add_idle([](gpointer data) -> gboolean {
            auto* p = static_cast<std::pair<ConsentWindow*, std::string>*>(data);
            ConsentWindow* win = p->first;
            std::string text = p->second;
            // Put transcript into input entry, focus it and copy to clipboard so user can paste/send quickly
            if (win->input_entry_) {
                set_input_text(win->input_entry_, text);
                // Give input focus
                gtk_widget_grab_focus(win->input_entry_);
                // Also copy transcript to clipboard
                GtkClipboard* cb = gtk_clipboard_get(GDK_SELECTION_CLIPBOARD);
                if (cb) {
                    gtk_clipboard_set_text(cb, text.c_str(), -1);
                    gtk_clipboard_store(cb);
                }
            }
            append_to_chat(GTK_TEXT_VIEW(win->get_chat_text_view()), "System", "✅ Transcription loaded into input box and copied to clipboard");
            delete p;
            return FALSE;
        }, new std::pair<ConsentWindow*, std::string>(self, transcript_text));
    }).detach();
}

// Save chat to file
void ConsentWindow::on_save_chat_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;

    GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(self->chat_text_view_));
    if (!buf) return;

    GtkTextIter start, end;
    gtk_text_buffer_get_start_iter(buf, &start);
    gtk_text_buffer_get_end_iter(buf, &end);
    gchar* text = gtk_text_buffer_get_text(buf, &start, &end, FALSE);
    if (!text) return;

    // Create output filename with timestamp
    std::time_t t = std::time(nullptr);
    char fname[512];
    snprintf(fname, sizeof(fname), "%s/gemini_chat_%lld.txt", 
             self->config_ ? self->config_->get_string("output_dir", "/tmp").c_str() : std::string("/tmp").c_str(),
             (long long)t);

    std::ofstream of(fname);
    if (!of.is_open()) {
        append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", "⚠️ Failed to save chat to file");
        g_free(text);
        return;
    }
    of << text;
    of.close();
    g_free(text);

    append_to_chat(GTK_TEXT_VIEW(self->get_chat_text_view()), "System", std::string("Saved chat to: ") + fname);
}

// Key press event handler for shortcuts
gboolean ConsentWindow::on_key_press(GtkWidget* widget, GdkEventKey* event, gpointer user_data) {
    (void)widget;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return FALSE;
    // Only respond to Ctrl+<key> mnemonics
    bool ctrl = (event->state & GDK_CONTROL_MASK) != 0;
    if (!ctrl) return FALSE;

    if (is_demo_mode()) {
        switch (event->keyval) {
            case GDK_KEY_r:
            case GDK_KEY_R:
                ConsentWindow::on_start_clicked(GTK_BUTTON(self->start_button_), self);
                return TRUE;
            case GDK_KEY_o:
            case GDK_KEY_O:
                ConsentWindow::on_stop_clicked(GTK_BUTTON(self->stop_button_), self);
                return TRUE;
            case GDK_KEY_h:
            case GDK_KEY_H:
                if (gtk_widget_get_visible(self->window_)) gtk_widget_hide(self->window_);
                else gtk_widget_show_all(self->window_);
                return TRUE;
            case GDK_KEY_q:
            case GDK_KEY_Q:
                gtk_main_quit();
                return TRUE;
            default:
                return FALSE;
        }
    }

    switch (event->keyval) {

          // existing mappings...
        case GDK_KEY_k: // Ctrl+K -> Toggle maximize (top-right "wide" button)
        case GDK_KEY_K:
            if (gtk_window_is_maximized(GTK_WINDOW(self->window_))) {
                gtk_window_unmaximize(GTK_WINDOW(self->window_));
                if (g_logger) g_logger->log("Window unmaximized (Ctrl+K)");
            } else {
                gtk_window_maximize(GTK_WINDOW(self->window_));
                if (g_logger) g_logger->log("Window maximized (Ctrl+K)");
            }
            return TRUE;
        
        case GDK_KEY_j: // Ctrl+J -> Toggle between compact and expanded size
        case GDK_KEY_J:
            {
                 if (gtk_window_is_maximized(GTK_WINDOW(self->window_))) {
            // If maximized, unmaximize first
                gtk_window_unmaximize(GTK_WINDOW(self->window_));
                if (g_logger) g_logger->log("Window unmaximized (Ctrl+J)");
            } else {
            // If not maximized, shrink to initial compact size
              gtk_window_resize(GTK_WINDOW(self->window_), 240, 320);
             if (g_logger) g_logger->log("Window minimized to initial size (Ctrl+J)");
                }
            }
            return TRUE;


        case GDK_KEY_r: // Ctrl+R -> Start
        case GDK_KEY_R:
            ConsentWindow::on_start_clicked(GTK_BUTTON(self->start_button_), self);
            return TRUE;
        case GDK_KEY_o: // Ctrl+T -> Stop
        case GDK_KEY_O:
            ConsentWindow::on_stop_clicked(GTK_BUTTON(self->stop_button_), self);
            return TRUE;
        case GDK_KEY_p: // Ctrl+P -> Full screenshot
        case GDK_KEY_P:
            ConsentWindow::on_screenshot_clicked(GTK_BUTTON(self->screenshot_button_), self);
            return TRUE;
        case GDK_KEY_t: // Ctrl+A -> Area screenshot
        case GDK_KEY_T:
            ConsentWindow::on_screenshot_area_clicked(GTK_BUTTON(self->screenshot_area_button_), self);
            return TRUE;
        case GDK_KEY_m: // Ctrl+M -> Stream
        case GDK_KEY_M:
            ConsentWindow::on_stream_clicked(GTK_BUTTON(self->stream_button_), self);
            return TRUE;
        case GDK_KEY_e: // Ctrl+E -> focus input entry
        case GDK_KEY_E:
            gtk_widget_grab_focus(self->input_entry_);
            // place cursor at end
            {
                GtkEntryBuffer* buf = gtk_entry_get_buffer(GTK_ENTRY(self->input_entry_));
                if (buf) {
                    int len = gtk_entry_buffer_get_length(buf);
                    gtk_editable_set_position(GTK_EDITABLE(self->input_entry_), len);
                }
            }
            return TRUE;
        case GDK_KEY_h: // Ctrl+H -> Hide/Show toggle
        case GDK_KEY_H:
            if (gtk_widget_get_visible(self->window_)) gtk_widget_hide(self->window_);
            else gtk_widget_show_all(self->window_);
            return TRUE;
        case GDK_KEY_b: // Ctrl+B -> Brightness up
        case GDK_KEY_B:
            {
                double cur = gtk_widget_get_opacity(self->window_);
                double next = std::min(1.0, cur + 0.05); // +5% per step
                gtk_widget_set_opacity(self->window_, next);
            }
            return TRUE;
        case GDK_KEY_n: // Ctrl+N -> Brightness down
        case GDK_KEY_N:
            {
                double cur = gtk_widget_get_opacity(self->window_);
                double next = std::max(0.0, cur - 0.05); // -5% per step
                gtk_widget_set_opacity(self->window_, next);
            }
            return TRUE;
        case GDK_KEY_d: // Ctrl+S -> Send/Ask Gemini
        case GDK_KEY_D:
            ConsentWindow::on_ask_clicked(GTK_BUTTON(self->ask_button_), self);
            return TRUE;
        case GDK_KEY_c: // Ctrl+C -> Copy selected text from chat or input
        case GDK_KEY_C:
        {
            // Try to copy from currently focused widget (chat or input)
            GtkWidget* focus = gtk_window_get_focus(GTK_WINDOW(self->window_));
            GtkClipboard* clipboard = gtk_clipboard_get(GDK_SELECTION_CLIPBOARD);
            
            if (focus && GTK_IS_TEXT_VIEW(focus)) {
                GtkTextBuffer* buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(focus));
                GtkTextIter start, end;
                
                // Check if there's a selection
                if (gtk_text_buffer_get_selection_bounds(buf, &start, &end)) {
                    // Copy selected text to clipboard
                    gchar* selected_text = gtk_text_buffer_get_text(buf, &start, &end, FALSE);
                    if (selected_text) {
                        gtk_clipboard_set_text(clipboard, selected_text, -1);
                        g_free(selected_text);
                        if (g_logger) g_logger->log("Copied selected text to clipboard");
                    }
                    return TRUE;
                }
            }
            
            // Fallback: copy entire chat display (if no selection)
            ConsentWindow::on_paste_clicked(GTK_BUTTON(self->paste_button_), self);
            return TRUE;
        }
        case GDK_KEY_l: // Ctrl+L -> Clear chat
        case GDK_KEY_L:
            ConsentWindow::on_clear_clicked(GTK_BUTTON(self->clear_button_), self);
            return TRUE;
        case GDK_KEY_x: // Ctrl+X -> Transcribe
        case GDK_KEY_X:
            ConsentWindow::on_transcribe_clicked(GTK_BUTTON(self->start_button_), self);
            return TRUE;
        case GDK_KEY_z: // Ctrl+V -> Stop Stream
        case GDK_KEY_Z:
            ConsentWindow::on_stop_stream_clicked(GTK_BUTTON(self->stop_stream_button_), self);
            return TRUE;
        //case GDK_KEY_v: // Ctrl+V -> Paste (load chat from clipboard into input)
        //case GDK_KEY_V:
           // ConsentWindow::on_paste_clicked(GTK_BUTTON(self->paste_button_), self);
           // return TRUE;
        case GDK_KEY_y: // Ctrl+Y -> Save chat
        case GDK_KEY_Y:
            ConsentWindow::on_save_chat_clicked(GTK_BUTTON(self->start_button_), self);
            return TRUE;
        case GDK_KEY_1: // Ctrl+1..4 -> Case 1..4
            ConsentWindow::on_case1_clicked(GTK_BUTTON(self->case1_button_), self);
            return TRUE;
        case GDK_KEY_2:
            ConsentWindow::on_case2_clicked(GTK_BUTTON(self->case2_button_), self);
            return TRUE;
        case GDK_KEY_3:
            ConsentWindow::on_case3_clicked(GTK_BUTTON(self->case3_button_), self);
            return TRUE;
        case GDK_KEY_4:
            ConsentWindow::on_case4_clicked(GTK_BUTTON(self->case4_button_), self);
            return TRUE;
        case GDK_KEY_u: // Ctrl+G -> Center and locate window
        case GDK_KEY_U:
            self->center_and_show_window();
            return TRUE;
        case GDK_KEY_f: // Ctrl+F -> Open search bar
        case GDK_KEY_F:
            self->show_search_bar();
            return TRUE;
        case GDK_KEY_w: // Ctrl+W -> Focus search entry (if search bar is visible)
        case GDK_KEY_W:
            if (self->search_bar_ && gtk_widget_get_visible(self->search_bar_)) {
                gtk_widget_grab_focus(self->search_entry_);
                gtk_editable_select_region(GTK_EDITABLE(self->search_entry_), 0, -1);
            } else {
                // If search bar is not visible, show it first
                self->show_search_bar();
            }
            return TRUE;
        case GDK_KEY_q: // Ctrl+Q -> Press search button (if search bar is visible)
        case GDK_KEY_Q:
            if (self->search_bar_ && gtk_widget_get_visible(self->search_bar_) && self->search_entry_) {
                const gchar* query = gtk_entry_get_text(GTK_ENTRY(self->search_entry_));
                bool case_sensitive = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(self->search_case_button_));
                self->perform_search(query, case_sensitive);
                if (g_logger) {
                    g_logger->log("Search triggered via Ctrl+Q: \"" + std::string(query) + "\"");
                }
            }
            return TRUE;
        default:
            return FALSE;
    }
}

// ===== WINDOW LOCATION HELPER =====

void ConsentWindow::center_and_show_window() {
    if (!window_) return;
    
    // Make window visible with 50% brightness
    gtk_widget_set_opacity(GTK_WIDGET(window_), 0.5);
    gtk_widget_show_all(window_);
    gtk_window_present(GTK_WINDOW(window_));
    
    // Check if cursor is inside window, if not move it inside
    move_cursor_if_outside();
    
    if (g_logger) g_logger->log("🎯 Window shown and cursor positioned");
}


// Helper: move cursor to center of window using X11
void ConsentWindow::move_cursor_if_outside() {
    if (!window_) return;
    
    // Get window position and size
    gint win_x, win_y, width, height;
    gtk_window_get_position(GTK_WINDOW(window_), &win_x, &win_y);
    gtk_window_get_size(GTK_WINDOW(window_), &width, &height);
    
    // Get current cursor position using X11
    Display* display = GDK_DISPLAY_XDISPLAY(gdk_display_get_default());
    if (!display) return;
    
    Window root_window = DefaultRootWindow(display);
    Window child_return;
    int root_x, root_y, win_x_ret, win_y_ret;
    unsigned int mask_return;
    
    XQueryPointer(display, root_window, &root_window, &child_return,
                  &root_x, &root_y, &win_x_ret, &win_y_ret, &mask_return);
    
    // Check if cursor is inside window bounds
    bool inside = (root_x >= win_x && root_x <= (win_x + width) &&
                   root_y >= win_y && root_y <= (win_y + height));
    
    if (inside) {
        if (g_logger) g_logger->log("✓ Cursor already inside window - no movement needed");
        // Give window focus anyway
        gtk_window_present(GTK_WINDOW(window_));
        return;
    }
    
    // Cursor is outside - move to window center
    gint center_x = win_x + width / 2;
    gint center_y = win_y + height / 2;
    
    XWarpPointer(display, None, root_window, 0, 0, 0, 0, center_x, center_y);
    XFlush(display);
    
    // Give window focus
    gtk_window_present(GTK_WINDOW(window_));
    
    if (g_logger) {
        g_logger->log("✓ Cursor was outside - moved to window center at (" + 
                     std::to_string(center_x) + ", " + std::to_string(center_y) + ")");
    }
}

// Update center_cursor_in_window to use the new logic
void ConsentWindow::center_cursor_in_window() {
    move_cursor_if_outside();
}
// ===== SEARCH/FIND FUNCTIONALITY =====

void ConsentWindow::show_search_bar() {
    if (!search_bar_) {
        // Create search bar popup (horizontal box with search controls)
        search_bar_ = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
        gtk_container_set_border_width(GTK_CONTAINER(search_bar_), 5);
        
        // Search label
        GtkWidget* search_label = gtk_label_new("Find:");
        gtk_box_pack_start(GTK_BOX(search_bar_), search_label, FALSE, FALSE, 0);
        
        // Search text entry
        search_entry_ = gtk_entry_new();
        gtk_entry_set_placeholder_text(GTK_ENTRY(search_entry_), "Type to search...");
        gtk_widget_set_size_request(search_entry_, 150, -1);
        gtk_box_pack_start(GTK_BOX(search_bar_), search_entry_, TRUE, TRUE, 0);
        
        // Status label (shows match count)
        search_status_label_ = gtk_label_new("0 matches");
        gtk_widget_set_size_request(search_status_label_, 80, -1);
        gtk_box_pack_start(GTK_BOX(search_bar_), search_status_label_, FALSE, FALSE, 0);
        
        // Case sensitive toggle button
        search_case_button_ = gtk_toggle_button_new_with_label("Aa");
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(search_case_button_), TRUE); // Case sensitive by default
        gtk_widget_set_tooltip_text(search_case_button_, "Toggle case sensitivity");
        gtk_box_pack_start(GTK_BOX(search_bar_), search_case_button_, FALSE, FALSE, 0);
        
        // Search button (replaces next/previous)
        GtkWidget* search_button = gtk_button_new_with_label("🔍 Search");
        g_signal_connect(search_button, "clicked", G_CALLBACK(ConsentWindow::on_search_button_clicked), this);
        gtk_box_pack_start(GTK_BOX(search_bar_), search_button, FALSE, FALSE, 0);
        
        // Close button
        GtkWidget* close_button = gtk_button_new_with_label("✕");
        g_signal_connect(close_button, "clicked", G_CALLBACK(ConsentWindow::on_search_close), this);
        gtk_box_pack_start(GTK_BOX(search_bar_), close_button, FALSE, FALSE, 0);
        
        // Pack search bar into vbox at position after chat label
        gtk_box_pack_start(GTK_BOX(vbox_), search_bar_, FALSE, FALSE, 0);
        gtk_box_reorder_child(GTK_BOX(vbox_), search_bar_, 8); // Position near top of chat section
    }
    
    gtk_widget_show_all(search_bar_);
    gtk_widget_grab_focus(search_entry_);
    gtk_editable_select_region(GTK_EDITABLE(search_entry_), 0, -1); // Select all text for quick replacement
}

void ConsentWindow::hide_search_bar() {
    if (search_bar_) {
        gtk_widget_hide(search_bar_);
        search_matches_.clear();
        search_current_match_ = 0;
        
        // Remove highlighting from chat text view
        GtkTextBuffer* chat_buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(chat_text_view_));
        GtkTextIter chat_start, chat_end;
        gtk_text_buffer_get_bounds(chat_buf, &chat_start, &chat_end);
        
        GtkTextTagTable* chat_tag_table = gtk_text_buffer_get_tag_table(chat_buf);
        if (gtk_text_tag_table_lookup(chat_tag_table, "search_highlight")) {
            gtk_text_buffer_remove_tag_by_name(chat_buf, "search_highlight", &chat_start, &chat_end);
        }
        
        // Remove highlighting from input widget
        GtkTextBuffer* input_buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(input_entry_));
        GtkTextIter input_start, input_end;
        gtk_text_buffer_get_bounds(input_buf, &input_start, &input_end);
        
        GtkTextTagTable* input_tag_table = gtk_text_buffer_get_tag_table(input_buf);
        if (gtk_text_tag_table_lookup(input_tag_table, "search_highlight")) {
            gtk_text_buffer_remove_tag_by_name(input_buf, "search_highlight", &input_start, &input_end);
        }
    }
}

void ConsentWindow::perform_search(const std::string& query, bool case_sensitive) {
    if (query.empty()) {
        gtk_label_set_text(GTK_LABEL(search_status_label_), "0 matches");
        return;
    }
    
    search_matches_.clear();
    int total_matches = 0;
    
    // ===== SEARCH IN CHAT DISPLAY =====
    GtkTextBuffer* chat_buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(chat_text_view_));
    GtkTextIter chat_start, chat_end;
    gtk_text_buffer_get_bounds(chat_buf, &chat_start, &chat_end);
    
    // Create highlight tag if it doesn't exist
    GtkTextTagTable* chat_tag_table = gtk_text_buffer_get_tag_table(chat_buf);
    if (!gtk_text_tag_table_lookup(chat_tag_table, "search_highlight")) {
        gtk_text_buffer_create_tag(chat_buf, "search_highlight",
            "background", "#FFFF00",  // Yellow background
            "foreground", "#000000",  // Black text
            NULL);
    }
    
    // Remove previous highlights from chat
    gtk_text_buffer_remove_tag_by_name(chat_buf, "search_highlight", &chat_start, &chat_end);
    
    // Get all text from chat
    gchar* chat_text_raw = gtk_text_buffer_get_text(chat_buf, &chat_start, &chat_end, FALSE);
    std::string chat_text(chat_text_raw ? chat_text_raw : "");
    g_free(chat_text_raw);
    
    // Find all matches in chat
    size_t pos = 0;
    if (case_sensitive) {
        while ((pos = chat_text.find(query, pos)) != std::string::npos) {
            search_matches_.push_back(pos);
            pos += query.length();
        }
    } else {
        std::string chat_text_lower = chat_text;
        std::string query_lower = query;
        std::transform(chat_text_lower.begin(), chat_text_lower.end(), chat_text_lower.begin(), ::tolower);
        std::transform(query_lower.begin(), query_lower.end(), query_lower.begin(), ::tolower);
        
        while ((pos = chat_text_lower.find(query_lower, pos)) != std::string::npos) {
            search_matches_.push_back(pos);
            pos += query_lower.length();
        }
    }
    
    // Highlight all matches in chat
    for (size_t i = 0; i < search_matches_.size(); ++i) {
        GtkTextIter match_start, match_end;
        gtk_text_buffer_get_iter_at_offset(chat_buf, &match_start, search_matches_[i]);
        gtk_text_buffer_get_iter_at_offset(chat_buf, &match_end, search_matches_[i] + query.length());
        gtk_text_buffer_apply_tag_by_name(chat_buf, "search_highlight", &match_start, &match_end);
    }
    
    total_matches += search_matches_.size();
    
    // Scroll to first match in chat if found
    if (!search_matches_.empty()) {
        GtkTextIter first_match;
        gtk_text_buffer_get_iter_at_offset(chat_buf, &first_match, search_matches_[0]);
        gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(chat_text_view_), &first_match, 0.1, FALSE, 0, 0);
    }
    
    // ===== SEARCH IN INPUT WIDGET =====
    GtkTextBuffer* input_buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(input_entry_));
    GtkTextIter input_start, input_end;
    gtk_text_buffer_get_bounds(input_buf, &input_start, &input_end);
    
    // Create highlight tag for input if it doesn't exist
    GtkTextTagTable* input_tag_table = gtk_text_buffer_get_tag_table(input_buf);
    if (!gtk_text_tag_table_lookup(input_tag_table, "search_highlight")) {
        gtk_text_buffer_create_tag(input_buf, "search_highlight",
            "background", "#FFFF00",  // Yellow background
            "foreground", "#000000",  // Black text
            NULL);
    }
    
    // Remove previous highlights from input
    gtk_text_buffer_remove_tag_by_name(input_buf, "search_highlight", &input_start, &input_end);
    
    // Get all text from input
    gchar* input_text_raw = gtk_text_buffer_get_text(input_buf, &input_start, &input_end, FALSE);
    std::string input_text(input_text_raw ? input_text_raw : "");
    g_free(input_text_raw);
    
    // Find all matches in input
    std::vector<int> input_matches;
    pos = 0;
    if (case_sensitive) {
        while ((pos = input_text.find(query, pos)) != std::string::npos) {
            input_matches.push_back(pos);
            pos += query.length();
        }
    } else {
        std::string input_text_lower = input_text;
        std::string query_lower = query;
        std::transform(input_text_lower.begin(), input_text_lower.end(), input_text_lower.begin(), ::tolower);
        std::transform(query_lower.begin(), query_lower.end(), query_lower.begin(), ::tolower);
        
        while ((pos = input_text_lower.find(query_lower, pos)) != std::string::npos) {
            input_matches.push_back(pos);
            pos += query_lower.length();
        }
    }
    
    // Highlight all matches in input
    for (size_t i = 0; i < input_matches.size(); ++i) {
        GtkTextIter match_start, match_end;
        gtk_text_buffer_get_iter_at_offset(input_buf, &match_start, input_matches[i]);
        gtk_text_buffer_get_iter_at_offset(input_buf, &match_end, input_matches[i] + query.length());
        gtk_text_buffer_apply_tag_by_name(input_buf, "search_highlight", &match_start, &match_end);
    }
    
    total_matches += input_matches.size();
    
    // If no matches in chat but found in input, scroll to input widget
    if (search_matches_.empty() && !input_matches.empty()) {
        GtkTextIter first_input_match;
        gtk_text_buffer_get_iter_at_offset(input_buf, &first_input_match, input_matches[0]);
        gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(input_entry_), &first_input_match, 0.1, FALSE, 0, 0);
        gtk_widget_grab_focus(input_entry_);  // Focus on input to show the highlight
    }
    
    // Update status label with total match count from both areas
    gchar status[64];
    if (total_matches == 0) {
        g_snprintf(status, sizeof(status), "0 matches");
    } else if (total_matches == 1) {
        g_snprintf(status, sizeof(status), "1 match");
    } else {
        g_snprintf(status, sizeof(status), "%d matches", total_matches);
    }
    gtk_label_set_text(GTK_LABEL(search_status_label_), status);
    
    if (g_logger) {
        g_logger->log("Search results: " + std::to_string(search_matches_.size()) + 
                     " in chat, " + std::to_string(input_matches.size()) + " in input");
    }
}

// Search button clicked - perform search and highlight all matches
void ConsentWindow::on_search_button_clicked(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    
    const gchar* query = gtk_entry_get_text(GTK_ENTRY(self->search_entry_));
    bool case_sensitive = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(self->search_case_button_));
    self->perform_search(query, case_sensitive);
    
    if (g_logger) {
        g_logger->log("Search performed: \"" + std::string(query) + "\" - " + 
                     std::to_string(self->search_matches_.size()) + " matches found");
    }
}

// Case sensitivity toggle
void ConsentWindow::on_search_case_toggled(GtkToggleButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    
    // Re-search with new case sensitivity setting when toggled
    const gchar* query = gtk_entry_get_text(GTK_ENTRY(self->search_entry_));
    if (query && strlen(query) > 0) {
        bool case_sensitive = gtk_toggle_button_get_active(button);
        self->perform_search(query, case_sensitive);
    }
}

// Close search bar
void ConsentWindow::on_search_close(GtkButton* button, gpointer user_data) {
    (void)button;
    ConsentWindow* self = static_cast<ConsentWindow*>(user_data);
    if (!self) return;
    self->hide_search_bar();
}