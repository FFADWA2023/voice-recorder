// filepath: /home/dell/ethical_assistant/src/ui/consent_window_demo_stubs.cpp
// Stubs for symbols declared in consent_window.h but not used in the demo build.
// Only screenshot and streaming callbacks live here; everything else is in consent_window_demo.cpp.
#include "consent_window.h"
#include "../capture/screenshot_capture.h"
#include "../network/screen_streamer.h"
#include "../utils/ocr_analyzer.h"
#include <gtk/gtk.h>

void ConsentWindow::on_screenshot_clicked(GtkButton*, gpointer) {}
void ConsentWindow::on_screenshot_area_clicked(GtkButton*, gpointer) {}
void ConsentWindow::on_stream_clicked(GtkButton*, gpointer) {}
void ConsentWindow::on_stop_stream_clicked(GtkButton*, gpointer) {}
void ConsentWindow::on_locate_window_clicked(GtkButton*, gpointer) {}
