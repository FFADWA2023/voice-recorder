#pragma once
// consent_window.h
// GTK3 small floating consent window for visible recording control + screenshot/OCR + Gemini chat.

#include <gtk/gtk.h>
#include <memory>
#include <string>
#include <vector>
#include <thread>
#include <atomic>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

// Structure to hold conversation message
struct ConversationMessage {
    std::string role;  // "user" or "assistant"
    std::string content;
};

class AppConfig;
class Logger;
class ScreenshotCapture;
class OCRAnalyzer;
class ScreenStreamer;
class AIService;

class ConsentWindow {
public:
    // Initialize GTK (call once at program start)
    static void init(int &argc, char** &argv);
    
    ConsentWindow(AppConfig* config = nullptr, Logger* logger = nullptr);
    ~ConsentWindow();
    
    // Show the floating window
    void show();
    
    // Hide the floating window
    void hide();
    
    // Run GTK main loop (blocks until gtk_main_quit)
    static void run();
    
    // UI callbacks (static for signal binding)
    static void on_start_clicked(GtkButton* button, gpointer user_data);
    static void on_stop_clicked(GtkButton* button, gpointer user_data);
    static void on_screenshot_clicked(GtkButton* button, gpointer user_data);
    static void on_screenshot_area_clicked(GtkButton* button, gpointer user_data);
    static void on_stream_clicked(GtkButton* button, gpointer user_data);
    static void on_stop_stream_clicked(GtkButton* button, gpointer user_data);
    static void on_locate_window_clicked(GtkButton* button, gpointer user_data);
    
    // Gemini chat callbacks
    static void on_ask_clicked(GtkButton* button, gpointer user_data);
    static void on_clear_clicked(GtkButton* button, gpointer user_data);
    static void on_paste_clicked(GtkButton* button, gpointer user_data);
    static void on_transcribe_clicked(GtkButton* button, gpointer user_data);
    static void on_save_chat_clicked(GtkButton* button, gpointer user_data);
    static gboolean on_key_press(GtkWidget* widget, GdkEventKey* event, gpointer user_data);
    static void on_case1_clicked(GtkButton* button, gpointer user_data);
    static void on_case2_clicked(GtkButton* button, gpointer user_data);
    static void on_case3_clicked(GtkButton* button, gpointer user_data);
    static void on_case4_clicked(GtkButton* button, gpointer user_data);
    
    // Search/Find callbacks
    static void on_search_button_clicked(GtkButton* button, gpointer user_data);
    static void on_search_case_toggled(GtkToggleButton* button, gpointer user_data);
    static void on_search_close(GtkButton* button, gpointer user_data);
    
    // Public accessors for helper functions (needed by query_gemini_and_display)
    GtkWidget* get_chat_text_view() const { return chat_text_view_; }
    AIService* get_ai_service() const { return ai_service_.get(); }

    // Conversation history management
    const std::vector<ConversationMessage>& get_conversation_history() const { return conversation_history_; }
    void add_to_conversation_history(const std::string& role, const std::string& content);
    void save_conversation_history(const std::string& filepath = "");
    void load_conversation_history(const std::string& filepath = "");
    void clear_conversation_history();
    
    // Search/Find helper methods
    void show_search_bar();
    void hide_search_bar();
    void perform_search(const std::string& query, bool case_sensitive);
    
    // Window location helper
    void center_and_show_window();
    void move_cursor_if_outside();
    void center_cursor_in_window();
    
    // Global hotkey thread (Ctrl+U)
    std::unique_ptr<std::thread> global_hotkey_thread_;
    std::atomic<bool> global_hotkey_running_ { false };

private:
    GtkWidget* window_;
    GtkWidget* vbox_;
    GtkWidget* indicator_label_; // shows large dot + text
    GtkWidget* start_button_;
    GtkWidget* stop_button_;
    GtkWidget* screenshot_button_;
    GtkWidget* screenshot_area_button_;
    GtkWidget* stream_button_;
    GtkWidget* stop_stream_button_;
    GtkWidget* status_label_; // small text status
    
    // Gemini chat widgets
    GtkWidget* chat_text_view_;      // Display responses
    GtkWidget* input_entry_;         // Text input field
    GtkWidget* ask_button_;          // Send button
    GtkWidget* clear_button_;        // Clear text button
    GtkWidget* paste_button_;        // Paste from clipboard button
    GtkWidget* case1_button_;        // Case 1 button
    GtkWidget* case2_button_;        // Case 2 button
    GtkWidget* case3_button_;        // Case 3 button
    GtkWidget* case4_button_;        // Case 4 button
    
    // Search/Find functionality
    GtkWidget* search_bar_;          // Search popup bar
    GtkWidget* search_entry_;        // Search text input
    GtkWidget* search_case_button_;  // Case sensitive toggle button
    GtkWidget* search_status_label_; // Status label showing match count
    int search_current_match_;       // Current match index
    std::vector<int> search_matches_; // Character offsets of matches in chat
    
    AppConfig* config_;
    Logger* logger_;
    
    std::unique_ptr<ScreenshotCapture> screenshot_capture_;
    std::unique_ptr<OCRAnalyzer> ocr_analyzer_;
    std::unique_ptr<ScreenStreamer> screen_streamer_;
    std::unique_ptr<AIService> ai_service_;
    // Path to last saved recording (set when recording stops)
    std::string last_recording_path_;


    // Conversation history (maintains context for multi-turn chat)
    std::vector<ConversationMessage> conversation_history_;
    std::string history_file_path_;  // Path to save/load conversation history
    
    // Helper to update visible indicator when recording starts/stops
    void set_recording_state(bool recording);
    
    // Disable copy
    ConsentWindow(const ConsentWindow&) = delete;
    ConsentWindow& operator=(const ConsentWindow&) = delete;
};