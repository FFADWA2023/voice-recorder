namespace RecorderBridge.Api.Models;

public sealed class RecorderOptions
{
    public string ExecutablePath { get; set; } = "/home/dell/ethical_assistant/build/src/ethical_assistant";
    public string WorkingDirectory { get; set; } = "/home/dell/ethical_assistant";
    public string StartArguments { get; set; } = string.Empty;
    public bool UseShellExecute { get; set; }
    public Dictionary<string, string> EnvironmentVariables { get; set; } = [];
}