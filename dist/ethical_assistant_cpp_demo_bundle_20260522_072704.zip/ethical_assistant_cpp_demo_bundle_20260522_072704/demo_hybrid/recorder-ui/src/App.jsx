import { useEffect, useMemo, useState } from 'react'
import './App.css'

function App() {
  const [status, setStatus] = useState({
    isRunning: false,
    processId: null,
    startedAtUtc: null,
    executablePath: '',
    lastError: null,
    lastProcessId: null,
    lastStartedAtUtc: null,
    lastExitCode: null,
    lastExitedAtUtc: null,
  })
  const [loading, setLoading] = useState(false)
  const [requestError, setRequestError] = useState('')

  const startedAtText = useMemo(() => {
    if (!status.startedAtUtc) {
      if (status.lastStartedAtUtc) {
        return `${new Date(status.lastStartedAtUtc).toLocaleString()} (last run)`
      }

      return 'Not running'
    }

    return new Date(status.startedAtUtc).toLocaleString()
  }, [status.startedAtUtc, status.lastStartedAtUtc])

  async function fetchStatus() {
    try {
      const response = await fetch('/api/recorder/status')
      if (!response.ok) {
        throw new Error('Unable to load recorder status')
      }

      const payload = await response.json()
      setStatus(payload)
      setRequestError('')
    } catch (err) {
      setRequestError(err.message)
    }
  }

  async function postAction(action) {
    setLoading(true)
    try {
      const response = await fetch(`/api/recorder/${action}`, { method: 'POST' })
      const payload = await response.json()

      if (!response.ok) {
        throw new Error(payload.message || `Failed to ${action} recorder`)
      }

      setStatus(payload.status)
      setRequestError('')
    } catch (err) {
      setRequestError(err.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchStatus()

    const timer = setInterval(() => {
      fetchStatus()
    }, 2000)

    return () => clearInterval(timer)
  }, [])

  return (
    <main className="layout">
      <section className="panel hero">
        <p className="badge">Urgent Client Demo Mode</p>
        <h1>Ethical Assistant Bridge</h1>
        <p className="subtitle">
          .NET + React UI on top of your existing C++ recorder kernel.
        </p>
      </section>

      <section className="panel status-panel">
        <div className="status-line">
          <span className={`dot ${status.isRunning ? 'live' : ''}`} />
          <strong>{status.isRunning ? 'Recording service live' : 'Recorder offline'}</strong>
        </div>
        <div className="grid">
          <article>
            <h2>Executable</h2>
            <p>{status.executablePath || 'Not configured'}</p>
          </article>
          <article>
            <h2>Process ID</h2>
            <p>{status.processId ?? status.lastProcessId ?? 'N/A'}</p>
          </article>
          <article>
            <h2>Started At</h2>
            <p>{startedAtText}</p>
          </article>
          <article>
            <h2>Last Exit Code</h2>
            <p>{status.lastExitCode ?? 'N/A'}</p>
          </article>
        </div>

        {requestError && (
          <p className="error-box">{requestError}</p>
        )}
        {status.lastError && (
          <p className="warn-box">Last backend error: {status.lastError}</p>
        )}
      </section>

      <section className="panel action-panel">
        <button
          type="button"
          onClick={() => postAction('start')}
          disabled={loading || status.isRunning}
          className="primary"
        >
          Start C++ Recorder
        </button>
        <button
          type="button"
          onClick={() => postAction('stop')}
          disabled={loading || !status.isRunning}
          className="danger"
        >
          Stop Recorder
        </button>
        <button type="button" onClick={fetchStatus} disabled={loading} className="ghost">
          Refresh Status
        </button>
      </section>

      <section className="panel notes">
        <h2>Migration Scope for Urgent Presentation</h2>
        <ul>
          <li>UI: React dashboard for operation and confidence during demo.</li>
          <li>Backend: .NET API that controls recorder lifecycle and status.</li>
          <li>Core: C++ audio recorder remains unchanged for reliability.</li>
          <li>Later: migrate internals incrementally only if needed.</li>
        </ul>
      </section>
    </main>
  )
}

export default App
